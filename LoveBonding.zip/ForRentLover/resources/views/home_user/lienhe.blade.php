@extends('master')
@section('content')

<div class="container">
    <h1 class="page-title">Liên hệ với chúng tôi</h1>
    <form action="" method="post" class="beta-form-checkout">
        <input type="hidden" name="_token" value="{{csrf_token()}}">
        <div class="row">
            @if(Session::has('thb_contact'))
            <div class="alert alert-success">{{Session::get('thb_contact')}}</div>
            @endif
            <div class="row" style="margin-left: 15%;">
                <div>
                    <label>Tên của bạn</label>
                    <input class="form-control" style="width: 700px; margin-bottom: 20px;" placeholder="Your name"
                        name="name" />
                    <label>Số điện thoại</label>
                    <input class="form-control" style="margin-bottom: 20px;" placeholder="Your phone number"
                        name="phone_number" />
                    <label>Địa chỉ Email</label>
                    <input class="form-control" style="margin-bottom: 20px;" placeholder="Your email" name="email" />
                    <label>Nhập nội dung</label>
                    <textarea class="form-control" style="margin-bottom: 20px;" placeholder="Ban Dang Co Thac Mac Gi?"
                        name="content"></textarea>
                    <button class="btn btn-primary" style="margin-bottom: 20px;">Liên Hệ</button>
                </div>

            </div>
    </form>
</div>

@endsection
