@extends('master')
@section('content')

<div class="container">
    <div class="row" style="margin-left: 15%;">
        <h1 class="page-title">Liên hệ dịch vụ thuê người yêu</h1>

        <!-- <div id="hotline">"Hotline: "<a href="tel:0395587260"> 0395 587 260</a></div> -->
        <form action="" method="post" class="beta-form-checkout">
        <input type="hidden" name="_token" value="{{csrf_token()}}">
        <div class="row">
            @if(Session::has('thb_datlich'))
            <div class="alert alert-success">{{Session::get('thb_datlich')}}</div>
            @endif
                <div class="region.region-content">
                    <!-- Phan thong tin cua khach hang -->
                    <fieldset class="panel panel-default form-wrapper">
                        <legend class="panel-heading">
                            <span class="panel-title fieldset-legend">Thông tin khách hàng</span>
                        </legend>
                        <div class="panel-body">
                            <div class="form-item form-item-customer-name form-type-textfield form-group">
                                <label class="control-label">Họ Và Tên</label>
                                <span class="form-required" title="Trường dữ liệu này là bắt buộc.">*</span>
                                <input class="form-control form-text required" name="name" />
                                <div class="help-block">Vui lòng nhập tên của bạn để tiện liên hệ.</div>
                            </div>
                            <div class="form-item form-item-customer-gender form-type-radios form-group">
                                <label class="control-label">Giới Tính</label>
                                <span class="form-required" title="Trường dữ liệu này là bắt buộc.">*</span>
                                <div>
                                    <!-- Default inline 1-->
                                    <div class="custom-control custom-radio custom-control-inline">
                                        <input type="radio" class="custom-control-input" id="Male" name="gender"
                                            value="Male" checked="checked">
                                        <label class="custom-control-label" for="Male">Nam</label>
                                    </div>

                                    <!-- Default inline 2-->
                                    <div class="custom-control custom-radio custom-control-inline">
                                        <input type="radio" class="custom-control-input" id="Female" name="gender"
                                            value="Female">
                                        <label class="custom-control-label" for="Female">Nữ</label>
                                    </div>
                                </div>
                            </div>
                            <div class="form-item form-item-appointment-city form-type-select form-group"
                                style="margin-top: 15px;">
                                <label class="control-label" for="edit-appointment-city">Địa điểm tại
                                    <span class="form-required" title="Trường dữ liệu này là bắt buộc.">*</span>
                                </label>
                                <div>
                                    <select class="selectpicker" style="width: 700px;" name="address">
                                        <option value="Da nang">Đà Nẵng</option>
                                        <option value="Ha Noi">Hà Nội</option>
                                        <option value="TP Ho Chi Minh">TP Hồ Chí Minh</option>
                                        <option value="Quang Binh">Quảng Bình</option>
                                        <option value="Quang Tri">Quảng Trị</option>
                                        <option value="Quang Nam">Quảng Nam</option>
                                        <option value="Binh Dinh">Bình Định</option>
                                        <option value="Quang Ngai">Quãng Ngãi</option>
                                        <option value="Hue">Huế</option>
                                    </select>

                                </div>
                            </div>
                            <div class="form-item form-item-customer-name form-type-textfield form-group"
                                style="margin-top: 15px;">
                                <label class="control-label">Điện thoại</label>
                                <span class="form-required" title="Trường dữ liệu này là bắt buộc.">*</span>
                                <input class="form-control form-text required" name="phone" />
                                <div class="help-block">Vui lòng nhập số điện thoại của bạn để tiện liên hệ.</div>
                            </div>
                            <div class="form-item form-item-customer-name form-type-textfield form-group">
                                <label class="control-label">Ghi Chu</label>
                                <textarea class="form-control form-text required" name="notes"></textarea>
                                <div class="help-block">Nếu có bất kì thắc mắc gì?.</div>
                            </div>
                        </div>
                    </fieldset>
                    <hr style="border: 1px solid red;">
                    <!-- Phan Thong tin cua nhan vien da duoc chon -->
                    <fieldset class="panel panel-default form-wrapper">
                        <legend class="panel-heading">
                            <span class="panel-title fieldset-legend">Nhân viên bạn đã chọn</span>
                        </legend>
                        <div class="panel-body">
                            <div class="col-md-3 col-sm-6">
                                <div class="product-grid3">
                                    <div class="product-image3">
                                        <a href="#">
                                            <img class="pic-1" src="image/product/{{ $employee->image }}">
                                            <img class="pic-2" src="image/product/{{ $employee->image }}">
                                        </a>
                                    </div>
                                    <div class="product-content">
                                        <h3 class="title"><a href="#">{{$employee->name}}</a></h3>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </fieldset>
                    <hr style="border: 1px solid red;">

                    <!-- Thong tin yeu cau tu Admin -->
                    <fieldset class="panel panel-default form-wrapper">
                        <legend class="panel-heading">
                            <span class="panel-title fieldset-legend">Thời gian / Thanh Toán / Mục Đích</span>
                        </legend>
                        <div class="panel-body">
                            <div class="form-item form-item-customer-name form-type-textfield form-group">
                                <label class="control-label">Ngày Đặt lịch</label>
                                <span class="form-required" title="Trường dữ liệu này là bắt buộc.">*</span>
                                <input class="form-control form-text required" name="check_in" type="datetime-local" />
                                <div class="help-block">Vui lòng chọn ngày trong tương lai.</div>
                            </div>
                            <div class="form-item form-item-customer-name form-type-textfield form-group">
                                <label class="control-label">Bao Nhiêu Giờ</label>
                                <input name="hours" placeholder="5$/hour" type="number" onkeyup="totalCal(this);" />

                                <script>
                                function totalCal(inputElement) {
                                    var hour = inputElement.value;
                                    var target = document.getElementById('sum');
                                    if (target != null) {
                                        target.innerHTML = hour * {{$employee->unit_price}} + "$";
                                    }
                                    document.getElementById('kq').value = hour * {{$employee->unit_price}};
                                }
                                </script>

                                <label class="control-label">Tổng Tiền:
                                    <input type="text" name="totalPrice" value="" id="kq" hidden />
                                    <span style="color: red;" name="totalPrice" id="sum" value="this"></span>
                                </label>
                            </div>
                            <div class="form-item form-item-customer-name form-type-textfield form-group">
                                <label class="control-label">Hình thức thanh toán</label>
                                <span class="form-required" title="Trường dữ liệu này là bắt buộc.">*</span>
                                <div>
                                    <select class="selectpicker" style="width: 700px;" name="payment">
                                        <option value="COD">Thanh toán khi gặp nhân viên</option>
                                        <option value="ATM">Chuyển khoản</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-item form-item-customer-name form-type-textfield form-group">
                                <label class="control-label">Mục đích</label>
                                <span class="form-required" title="Trường dữ liệu này là bắt buộc.">*</span>
                                <div>
                                    <!-- Default unchecked -->
                                    <div class="custom-control custom-radio">
                                        <input type="radio" class="custom-control-input" id="diChoi" name="note" value="Cùng đi chơi / đi ăn
                                            /trò chuyện tâm sự" checked="checked" />
                                        <label class="custom-control-label" for="diChoi">Cùng đi chơi / đi ăn
                                            /trò chuyện tâm sự</label>
                                    </div>
                                    <div class="custom-control custom-radio">
                                        <input type="radio" class="custom-control-input" id="sinhNhat" name="note"
                                            value="Dự sinh nhật / dự tiệc">
                                        <label class="custom-control-label" for="sinhNhat">Dự sinh nhật / dự
                                            tiệc</label>
                                    </div>
                                    <div class="custom-control custom-radio">
                                        <input type="radio" class="custom-control-input" id="giaDinh" name="note"
                                            value="Thăm gia đình, ra mắt bố mẹ">
                                        <label class="custom-control-label" for="giaDinh">Thăm gia đình, ra mắt bố
                                            mẹ</label>
                                    </div>
                                    <div class="custom-control custom-radio">
                                        <input type="radio" class="custom-control-input" id="duLich" name="note"
                                            value="Đi du lịch, chơi dã ngoại / picnic">
                                        <label class="custom-control-label" for="duLich">Đi du lịch, chơi dã ngoại /
                                            picnic</label>
                                    </div>
                                    <div class="custom-control custom-radio">
                                        <input type="radio" class="custom-control-input" id="huongDanVien" name="note"
                                            value="Hướng dẫn viên địa phương">
                                        <label class="custom-control-label" for="huongDanVien">Hướng dẫn viên địa
                                            phương</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </fieldset>
                    <hr style="border: 1px solid red;">
                    <fieldset>
                        <button class="btn btn-success">Gửi Yêu Cầu</button>
                    </fieldset>
                </div>
            </div>
        </form>
    </div>
</div>

@endsection
