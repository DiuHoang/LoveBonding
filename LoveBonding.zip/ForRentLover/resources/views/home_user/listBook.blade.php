@extends('master')
@section('content')
<!-- Phan Thong tin cua nhan vien da duoc chon -->
<fieldset class="panel panel-default form-wrapper">
    <legend class="panel-heading">
        <span class="panel-title fieldset-legend">Nhan Vien Ban Da Chon</span>
    </legend>
    <div class="col-md-3 col-sm-6" style="margin-top: 50px;">
            <div class="product-grid3">
                <div class="product-image3">
                    <a href="#">
                        <img class="pic-1" src="image/product/{{ $employee->image }}">
                        <img class="pic-2" src="image/product/{{ $employee->image }}">
                    </a>
                    <ul class="social">
                        <li><a href="#"><i class="fa fa-comments"></i></a></li>

                        <li><a href="{{ route('datLich', $employee->id) }}"><i class="fa fa-calendar-o"></i></a>
                        </li>
                       
                    </ul>
                    
                </div>
                <div class="product-content">
                    <h3 class="title"><a href="#">{{$employee->name}}</a></h3>
                    <div class="price">
                        {{$employee->unit_price}} $/ Date
                        <!-- <span>$75.00</span> -->
                    </div>
                    <ul class="rating">
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star disable"></li>
                        <li class="fa fa-star disable"></li>
                    </ul>
                </div>
            </div>
        </div>
</fieldset>
<hr style="border: 1px solid red;">
@endsection