@extends('master')
@section('content')
<div class="container">
	<form class="form_resgister" action="{{route('dangki')}}" method="post">
		@csrf
		<h2>LOVE BONDING</h2>
		<div class="inputs">
			<label>Email</label>
			<input type="email" name="email" placeholder="Email">

			<label>User Name</label>
			<input type="text" name="name" placeholder="Username">

            <label>Phone Number</label>
			<input type="text" name="phonenumber" placeholder="Phone Number">

            <label>Image</label>
			<input type="file" name="image" placeholder="Phone Number">

            <label>Gender</label>
			<select
                 name="gender">
                <option value="male">Male</option>
                <option value="female">Female</option>
			</select>

			<label style="margin-top:10px;">Password</label>
			<input type="password" name="password" placeholder="Password">

			<label>Confirm Password</label>
			<input type="password" name="repassword" placeholder="confirm-password">

			@if (count($errors) >0)
				<ul>
					@foreach($errors->all() as $error)
						<li class="text-danger"> <center>{{ $error }}</center></li>
					@endforeach
				</ul>
     		@endif

		</div>
		<button id="button_register">ĐĂNG KÍ</button>
	</form>
</div>
@endsection
