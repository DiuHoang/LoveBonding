@extends('master')
@section('content')
<!-- cua tui -->
<div class="container">
    <div class="pull-left">
        <h6 class="inner-title"></h6>
    </div>
    <div class="pull-right">
        <div class="beta-breadcrumb font-large">
            <a href="{{route('trang-chu')}}">Trang chủ</a> / <span>Loại nhân viên</span>
        </div>
    </div>
    <div class="space50">&nbsp;</div>
    <div class="clearfix"></div>

    <!-- sp chinh -->
    <div class="row">
        <div class="space50">&nbsp;</div>
        <div>
            <h4>Nhân viên chính</h4>

            <p class="pull-left">Tìm thấy {{count($emp_theoloai)}} Nhân Viên</p>
            <div class="clearfix"></div>
        </div>

        @foreach($emp_theoloai as $emp)
        <div class="col-md-3 col-sm-6">
            <div class="product-grid3">
                <div class="product-image3">

                    <a href="{{ route('chitietsanpham', $emp->id) }}">
                        <img class="pic-1" src="image/product/{{ $emp->image }}">
                        <img class="pic-2" src="image/product/{{ $emp->image }}">
                    </a>
                    <ul class="social">
                        <li><a href="{{ route('lienhe') }}"><i class="fa fa-comments"></i></a></li>

                        <li><a href="{{ route('datLich', $emp->id) }}"><i class="fa fa-calendar-o"></i></a>
                        </li>

                    </ul>
                    <span class="product-new-label">New</span>
                </div>
                <div class="product-content">
                    <h3 class="title"><a href="#">{{$emp->name}}</a></h3>
                    <div class="price">
                        {{$emp->unit_price}} $/ Date
                        <!-- <span>$75.00</span> -->
                    </div>
                    <ul class="rating">
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star disable"></li>
                        <li class="fa fa-star disable"></li>
                    </ul>
                </div>
            </div>
        </div>
        @endforeach
        <div class="space50">&nbsp;</div>
    </div>
    <!-- sp khac -->
    <div class="row">
        <div class="space50">&nbsp;</div>

        <div class="space50">&nbsp;</div>

        <div>
            <h4>Nhân Viên Khác</h4>

            <p class="pull-left">Tìm thấy {{count($emp_khac)}} Nhân Viên</p>
            <div class="clearfix"></div>
        </div>

        @foreach($emp_khac as $emp_k)
        <div class="col-md-3 col-sm-6">
            <div class="product-grid3">
                <div class="product-image3">

                    <a href="{{ route('chitietsanpham', $emp_k->id) }}">
                        <img class="pic-1" src="image/product/{{ $emp_k->image }}">
                        <img class="pic-2" src="image/product/{{ $emp_k->image }}">
                    </a>
                    <ul class="social">
                        <li><a href="{{ route('lienhe') }}"><i class="fa fa-comments"></i></a></li>

                        <li><a href="{{ route('datLich', $emp_k->id) }}"><i class="fa fa-calendar-o"></i></a>
                        </li>

                    </ul>
                    <span class="product-new-label">New</span>
                </div>
                <div class="product-content">
                    <h3 class="title"><a href="#">{{$emp_k->name}}</a></h3>
                    <div class="price">
                        {{$emp_k->unit_price}} $/ Date
                        <!-- <span>$75.00</span> -->
                    </div>
                    <ul class="rating">
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star disable"></li>
                        <li class="fa fa-star disable"></li>
                    </ul>
                </div>
            </div>
        </div>
        @endforeach


    </div>
</div>


@endsection
