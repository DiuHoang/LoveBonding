@extends('master')
@section('content')
<div class="container">
    <script>
		var msg = '{{Session::get('alert')}}';
		var exist = '{{Session::has('alert')}}';
		if(exist){
		  alert(msg);
		}
	</script>
	<form class="form_login" action="{{route('dangnhap')}}" method="post">
    @csrf
		<h2>FOR RENT LOVER</h2>

		<div class="name_pass">
			<label>Email</label>
			<input
				type="text"
				name="email"
				placeholder="Enter your email"
			>
			<label style="margin-top: 10px;">Password</label>
			<input
				type="password"
				name="password"
				placeholder="Password"
			>
		</div>
		@if (count($errors) >0)
		<ul>
			@foreach($errors->all() as $error)
				<li class="text-danger"> <p>{{ $error }}</p></li>
			@endforeach
		</ul>
		@endif
		<button id="button_login" type="submit">SIGN IN</button>
		<label id="lbunder_login">Or sign in with</label>

		<div class="div_button">
			<button><i style="color: blue; padding-right: 1px;" class="fa fa-facebook"></i>Facebook</button>
			<button><i style="color: red; padding-right: 3px;"class="fa fa-google-plus"></i>Google</button>
		</div>

		<label id="lb_footer">Not a member?<a href="{{route('dangki')}}"><span> Sign up now</span></a></label>
	</form>

</div>
@endsection

