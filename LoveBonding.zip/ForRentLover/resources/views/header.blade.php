<div>
<!-- {{-- Sript for alert --}} -->
<script>
    var msg = '{{Session::get('alert')}}';
    var exist = '{{Session::has('alert')}}';
    if(exist){
      alert(msg);
    }
</script>
    <div class="header-blue">
        <nav class="navbar navbar-light navbar-expand-md navigation-clean-search">
            <div class="container-fluid"><a class="navbar-brand" href="#"><img src="image/slide/logoo.png"/></a><button data-toggle="collapse"
                    class="navbar-toggler" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span
                        class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navcol-1">
                    <ul class="nav navbar-nav">
                        <li class="nav-item" role="presentation"><a class="nav-link" href="{{route('trang-chu')}}">HOME</a></li>
                        <li class="nav-item dropdown"><a class="dropdown-toggle nav-link" data-toggle="dropdown"
                                aria-expanded="false" href="#">CATEGORRIES</a>
                            <ul>
                                <div class="dropdown-menu" role="menu">

                                    @foreach($type as $loai)
                                    <li class="dropdown-item"><a href="{{ route('loainhanvien' , $loai->id) }}">{{$loai->gender}}</a></li>
                                    @endforeach
                                </div>
                            </ul>
                        </li>
                    </ul>
                    <form class="form-inline mr-auto" target="_self">
                        <div class="input-group">
                        {{-- @csrf --}}
                            <input type="text" class="form-control" name="search" placeholder="Search this Website">
                            <div class="input-group-append">
                                <button class="btn btn-secondary" type="submit">
                                    <i class="fa fa-search"></i>
                                </button>
                            </div>
                            {{-- @if(count($errors) >0)
                                <ul>
                                    @foreach($errors->all() as $error)
                                        <li class="text-danger"> <center>{{ $error }}</center></li>
                                    @endforeach
                                </ul>
                            @endif --}}
                        </div>
                    </form>
                    @if (session('infor'))
                        <span style="background-color:brown; border-radius: 30%;">Welcome {{ Session::get('infor')[0]->name }}</span> &emsp;
                        <a class="btn btn-light action-button" role="button" href="{{route('dangxuat')}}">Log out</a>
                    @else
                        <span class="navbar-text"> <a class="login" href="{{route('dangnhap')}}">Login</a></span>
                        <a class="btn btn-light action-button" role="button" href="{{route('dangki')}}">Sign Up</a>
                    @endif
                </div>
            </div>
        </nav>
    </div>
</div>
<!-- Slide -->
<div class="header-image"
    style="background-image: url('image/slide/header2.jpg'); background-position: center; height: 500px; width: 100%; background-size: cover; background-repeat: no-repeat; margin-bottom: 20px">
    <p style="margin-left: 100px; padding-top: 60px; font-size: 50px;color:white">Welcome to our Studio</p>
    <h1 style="margin-left: 100px; padding-top: 10px; font-weight: bold; font-size: 60px">IT'S NICE MEET YOU</h1>
    <a href="{{ route('lienhe') }}"><button style="box-shadow: 0 0 0 .2rem rgba(221,183,52,.5); color: #212529;
        background-color: #fec503;
        border-color: #f3bd01; margin-left: 5%; margin-top: 20px; width: 150px">Tell Us More
        </button></a>
</div>
