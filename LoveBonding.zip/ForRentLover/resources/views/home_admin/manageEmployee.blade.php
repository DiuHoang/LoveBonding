@extends('master')
@section('content')
<a href="{{ route('trang_chu')}}"><button class="btn btn-dark">Back Home</button></a>
<div class="container">
    <a href="{{ route('insert') }}">
        <button class="btn btn-info">
            <i class="fa fa-plus-circle"> ADD</i>
        </button>
    </a>
    <a href="{{route('sort')}}">
        <button class="btn btn-success">
            <i class="fa fa-sort"> SORT</i>
        </button>
    </a>
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#staticBackdrop">
            <i class="fa fa-rank"> RANK</i>
        </button>
    <center>
        <table class="table">
            <thead class="thead-dark">
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th class="image">Image</th>
                    <th>Gender</th>
                    <th>Phone Number</th>
                    <th>Address</th>
                    <th>Description</th>
                    <th>Unit Price</th>
                    <th>Action</th>
                </tr>
            </thead>
            @foreach ( $employees as $employee)
            <tbody>
                <tr>
                    <td>{!! $employee['id'] !!}</td>
                    <td>{!! $employee['name'] !!}</td>
                    <td><img src="image/product/{{$employee->image}} " width="50px" height="50px"></td>
                    <td>{!! $employee['id_type'] !!}</td>
                    <td>{!! $employee['phone_number'] !!}</td>
                    <td>{!! $employee['address'] !!}</td>
                    <td>{!! $employee['description'] !!}</td>
                    <td>{!! $employee['unit_price'] !!}</td>
                    <td class="action">
                        <a href="{!! route('update', $employee['id']) !!}">
                            <button class="btn btn-warning" name="edit" value="{!! $employee['id'] !!}"><i
                                    class="fa fa-edit"></i></button>
                        </a>
                        <a href="{!! route('delete', $employee['id'] )!!}">
                            <button class="btn btn-danger" name="delete" value="{!! $employee['id'] !!}"><i
                                    class="fa fa-trash"></i></button>
                        </a>
                    </td>
                </tr>
            </tbody>
            @endforeach
        </table>
    </center>
    <div class="modal fade" id="staticBackdrop" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">XẾP HẠNG 3 NGƯỜI CÓ NHIỀU ĐƠN NHẤT</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Phần này chưa làm xong
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
