@extends('master')
@section('content')
<div class="container">
    <center>
        <table class="table">
            <thead class="table-danger">
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Gender</th>
                    <th>Address</th>
                    <th>Phone Number</th>
                    <th>Note</th>
                </tr>
            </thead>
            @foreach ( $customers as $customer)
            <tbody>
                <tr>
                    <td>{!! $customer['id'] !!}</td>
                    <td>{!! $customer['name'] !!}</td>
                    <td>{!! $customer['gender'] !!}</td>
                    <td>{!! $customer['address'] !!}</td>
                    <td>{!! $customer['phone_number'] !!}</td>
                    <td>{!! $customer['note'] !!}</td>
                </tr>
            </tbody>
            @endforeach
        </table>
    </center>
</div>
@endsection