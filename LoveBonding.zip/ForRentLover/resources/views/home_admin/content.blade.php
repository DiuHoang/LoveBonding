@extends('master')
@section('content')
@include('home_admin.header')
<div class="row">
    <div class="col-lg-7 col-xl-8">
    </script>  
        <!-- ***************************************** -->
        <div id="piechart"></div>
        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
        <script type="text/javascript">
        // Load google charts
        google.charts.load('current', {'packages':['corechart']});
        google.charts.setOnLoadCallback(drawChart);

        // Draw the chart and set the chart values
        function drawChart() {
            var data = google.visualization.arrayToDataTable([
                ['Task', 'Hours per Day'],
            @foreach($genders as $g)
            ['{!! $g['id_type'] !!}', {!! $g['e'] !!}],
            @endforeach
        ]);

          // Optional; add a title and set the width and height of the chart
          var options = {'title':'ti le gioi tinh cua nhan vien', 'width':550, 'height':400};

          // Display the chart inside the <div> element with id="piechart"
          var chart = new google.visualization.PieChart(document.getElementById('piechart'));
          chart.draw(data, options);
        }
        </script>
    </div>
</div>
</div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a>

@endsection
