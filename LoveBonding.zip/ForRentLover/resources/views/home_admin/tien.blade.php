@extends('master')
@section('content')
<a href="{{ route('trang_chu')}}"><button class="btn btn-dark">Back Home</button></a>

<div class="container">
    <center>
        <table class="table">
            <thead class="table-info">
                <tr>
                    <th>Tháng</th>
                    <th>Số tiền kiếm được</th>
                    <th>Số lượng đơn hàng</th>
                </tr>
            </thead>
            @foreach ( $sum_bill as $sum)
            <tbody>
                <tr>
                    <td>{!! $sum['month'] !!}</td>
                    <td>{!! $sum['s'] !!} $</td>
                    <td>{!! $sum['c'] !!} đơn</td>
                </tr>
            </tbody>
            @endforeach
        </table>
    </center>
</div>
@endsection
