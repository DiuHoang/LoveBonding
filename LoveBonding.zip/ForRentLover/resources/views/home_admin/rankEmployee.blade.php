@extends('master')
@section('content')
<div class="container">
   
</div>
@endsection