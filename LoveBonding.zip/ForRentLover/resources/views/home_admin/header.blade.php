<nav class="navbar navbar-light navbar-expand bg-white shadow mb-4 topbar static-top">
    <div class="container-fluid"><button class="btn btn-link d-md-none rounded-circle mr-3" id="sidebarToggleTop" type="button"><i class="fa fa-bars"></i></button>
        <form class="form-inline d-none d-sm-inline-block mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
            <div class="input-group"><input class="bg-light form-control border-0 small" type="text" placeholder="Search for ...">
                <div class="input-group-append"><button class="btn btn-primary py-0" type="button"><i class="fa fa-search"></i></button></div>
            </div>
        </form>
        <ul class="nav navbar-nav flex-nowrap ml-auto">
            <li class="nav-item dropdown d-sm-none no-arrow"><a class="dropdown-toggle nav-link" data-toggle="dropdown" aria-expanded="false" href="#"><i class="fa fa-search"></i></a>
                <div class="dropdown-menu dropdown-menu-right p-3 animated--grow-in" role="menu" aria-labelledby="searchDropdown">
                    <form class="form-inline mr-auto navbar-search w-100">
                        <div class="input-group"><input class="bg-light form-control border-0 small" type="text" placeholder="Search for ...">
                            <div class="input-group-append"><button class="btn btn-primary py-0" type="button"><i class="fa fa-search"></i></button></div>
                        </div>
                    </form>
                </div>
            </li>
            <li class="nav-item dropdown no-arrow mx-1" role="presentation">
                <div class="nav-item dropdown no-arrow">
                    <a href="admin" class="dropdown-toggle nav-link" >
                        <i class="fa fa-home fa-fw"></i>
                    </a>
                </div>
            </li>
            <li class="nav-item dropdown no-arrow mx-1" role="presentation">
                <div class="nav-item dropdown no-arrow"><a class="dropdown-toggle nav-link" data-toggle="dropdown" aria-expanded="false" href="#"><span class="badge badge-danger badge-counter">...</span><i class="fa fa-bell fa-fw"></i></a>
                    <div class="dropdown-menu dropdown-menu-right dropdown-list dropdown-menu-right animated--grow-in" role="menu">
                        <h6 class="dropdown-header">Thong bao</h6>
                        <a class="d-flex align-items-center dropdown-item" href="#">
                            <div class="mr-3">
                                <div class="bg-primary icon-circle"><i class="fa fa-file-alt text-white"></i></div>
                            </div>
                            <div><span class="small text-gray-500">December 12, 2019</span>
                                <p>A new monthly report is ready to download!</p>
                            </div>
                        </a>
                        <a class="text-center dropdown-item small text-gray-500" href="#">Show All
                            Alerts</a>
                    </div>
                </div>
            </li>
            <li class="nav-item dropdown no-arrow mx-1" role="presentation">
                <div class="nav-item dropdown no-arrow"><a class="dropdown-toggle nav-link" data-toggle="dropdown" aria-expanded="false" href="#"><i class="fa fa-envelope fa-fw"></i><span class="badge badge-danger badge-counter">{{count($mess)}}</span></a>
                    <div class="dropdown-menu dropdown-menu-right dropdown-list dropdown-menu-right animated--grow-in" role="menu">
                        <h6 class="dropdown-header">Message</h6>
                        @foreach($result as $results)
                        <a class="d-flex align-items-center dropdown-item" href="#">

                            <div class="dropdown-list-image mr-3">
                                <img class="rounded-circle" src="image/product/nga.jpg">
                                <div class="bg-success status-indicator"></div>
                            </div>
                            <div class="font-weight-bold">

                                <div class="text-truncate"><span>{!! $results['content'] !!}</span></div>
                                <p class="small text-gray-500 mb-0">{!! $results['name'] !!}</p>

                            </div>
                        </a>
                        @endforeach
                        <a class="text-center dropdown-item small text-gray-500" href="#">Show All
                            Alerts</a>
                    </div>
                </div>
                <div class="shadow dropdown-list dropdown-menu dropdown-menu-right" aria-labelledby="alertsDropdown"></div>
            </li>
            <div class="d-none d-sm-block topbar-divider"></div>
            <li class="nav-item dropdown no-arrow" role="presentation">
                <div class="nav-item dropdown no-arrow"><a class="dropdown-toggle nav-link" data-toggle="dropdown" aria-expanded="false" href="#"><span class="d-none d-lg-inline mr-2 text-gray-600 small">Valerie
                            Luna</span><img class="border rounded-circle img-profile" src="image/product/avatar5.jpeg"></a>
                    <div class="dropdown-menu shadow dropdown-menu-right animated--grow-in" role="menu">
                        <a class="dropdown-item" role="presentation" href="#"><i class="fa fa-user fa-sm fa-fw mr-2 text-gray-400"></i>&nbsp;Profile</a><a class="dropdown-item" role="presentation" href="#"><i class="fa fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>&nbsp;Settings</a>
                        <a class="dropdown-item" role="presentation" href="#"><i class="fa fa-list fa-sm fa-fw mr-2 text-gray-400"></i>&nbsp;Activity
                            log</a>
                        <div class="dropdown-divider"></div><a class="dropdown-item" role="presentation" href="#"><i class="fa fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>&nbsp;Logout</a>
                    </div>
                </div>
            </li>
        </ul>
    </div>
</nav>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-6 col-xl-3 mb-4">
            <div class="card shadow border-left-primary py-2">
                <div class="card-body">
                    <div class="row align-items-center no-gutters">
                        <div class="col mr-2">
                            <a href="{{ route('bill') }}">
                                <div class="text-uppercase text-primary font-weight-bold text-xs mb-1">
                                    <span>Tổng số đơn</span></div>
                                <div class="text-dark font-weight-bold h5 mb-0"><span>Tổng: {{count($bills)}} đơn</span>
                                </div>
                            </a>
                        </div>
                        <div class="col-auto"><i class="fa fa-calendar fa-2x text-gray-300"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-xl-3 mb-4">
            <div class="card shadow border-left-success py-2">
                <div class="card-body">
                    <div class="row align-items-center no-gutters">
                        <div class="col mr-2">
                            <a href="{{ route('sum')}}">
                                <div class="text-uppercase text-success font-weight-bold text-xs mb-1">
                                    <span>Số tiền kiếm được</span></div>
                                <div class="text-dark font-weight-bold h5 mb-0"><span>Tổng: {{$totalPrice}}</span>
                                </div>
                            </a>
                        </div>
                        <div class="col-auto"><i class="fa fa-dollar-sign fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-xl-3 mb-4">
            <div class="card shadow border-left-success py-2">
                <div class="card-body">
                    <div class="row align-items-center no-gutters">
                        <div class="col mr-2">
                            <a href="{{ route('employee')}}">
                                <div class="text-uppercase text-success font-weight-bold text-xs mb-1">
                                    <span>Quản Lý Nhân Viên </span></div>
                                <div class="text-dark font-weight-bold h5 mb-0"><span>Số lượng: {{count($employees)}} nhân viên </span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-xl-3 mb-4">
        <div class="card shadow border-left-warning py-2">
            <div class="card-body">
                <div class="row align-items-center no-gutters">
                    <div class="col mr-2">
                    <a href="{{ route('customer')}}">
                        <div class="text-uppercase text-warning font-weight-bold text-xs mb-1">
                            <span>danh sach khach hang</span></div>
                        <div class="text-dark font-weight-bold h5 mb-0"><span>Số lượng: {{count($mess)}} khach hang
                        </span></div>
                    </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
