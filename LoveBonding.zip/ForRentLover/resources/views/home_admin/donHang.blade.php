
@extends('master')
@section('content')
<a href="{{ route('trang_chu')}}"><button class="btn btn-dark">Back Home</button></a>

<div class="container">
    <center>
        <table class="table">
            <thead class="table-info">
                <tr>
                    <th>Tên Khách Hàng</th>
                    <th>Tên Nhân viên</th>
                    <th>Ngày Đặt Lịch</th>
                </tr>
            </thead>
            @foreach ( $bill as $bills)
            <tbody>
                <tr>
                    <td>{!! $bills['customer_name'] !!}</td>
                    <td>{!! $bills['employee_name'] !!}</td>
                    <td>{!! $bills['date_book'] !!}</td>
                </tr>
            </tbody>
            @endforeach
        </table>
    </center>
</div>
@endsection
