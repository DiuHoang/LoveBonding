<!DOCTYPE html>
<html>
<head>
	<title>INSERT</title>

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/all.css" integrity="sha384-/rXc/GQVaYpyDdyxK+ecHPVYJSN9bmVFBvjA/9eOB+pb3F2w2N6fc5qB9Ew5yIns" crossorigin="anonymous">

	<link rel="stylesheet" type="text/css" href="{{asset('public/css')}}/insertStyle.css" >
</head>
<body>
	<center>
		<h1>Add New Employee</h1>
		<div class="insert">
			<div class="left">
				<img src="" width="200">
			</div>
			<div class="container">

				<form method="post" enctype="multipart/form-data">
					@csrf
				    <br>
				    <input type="" class="form-control" placeholder="Nguyễn Anh" name="name">
				    <br>
				    <input type="" class="form-control" placeholder="Quảng Bình" name="address">
				    <br>
				    <input type="" class="form-control" placeholder="18" name="age">
				    <br>
				    <input type="" class="form-control" placeholder="Cute" name="description">
				    <br>
				    <input type="" class="form-control" placeholder="100.000" name="price">
				    <br>
				    <input type="" class="form-control" placeholder="123456789" name="phone_number">
				    <br>
				    <select class="form-control" name="gender" id="sel1">
				        <option value="1">Male</option>
				    	<option value="2">Female</option>
				    	<option value="3">Mixed</option>
			      	</select>
				    <br>
				    <input type="file" class="form-control" name="myFile" id="myFile">
			    	<br>
				    <button type="submit" class="btn btn-success" name="sub">Submit</button>
				</form>

			</div>

		</div>
	</center>
</body>
</html>
