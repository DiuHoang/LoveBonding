<!DOCTYPE html>
<html>
<head>
	<title>About US</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
	<style type="text/css">
		.dev{
			margin: 5%;
			display: flex; 
			align-items: center; 
			justify-content: center;
		}
		.content{
			margin: 5%;
		}
		body{
			background-color: pink
		}
	</style>
</head>
<body>
	<div class="dev" >
		<div class="container">
			<center>
				<h2>Mai Thi Nga </h2>
	  			<p>Developer</p>            
	  			<img src="img/nga.jpg" class="rounded-circle" alt="Cinque Terre" width="305" height="300"> 
			</center>
		</div>
		<div class="container">
			<center>
		  	<h2>Hoang Thi Diu</h2>
		  	<p>Developer</p>            
		  	<img src="img/diu.jpg" class="rounded-circle" alt="Cinque Terre" width="305" height="300"> 
		   	</center>
		</div>
		<div class="container">
			<center>
		  	<h2>Ho Van Quan</h2>
		  	<p>Developer</p>            
		  	<img src="img/quan.jpg" class="rounded-circle" alt="Cinque Terre" width="305" height="300">
		  	</center> 
		</div>
	</div>
	<div class="content">
		<h1>Who are we?</h1>
		<h5>Chúng tôi là những sinh viên của PNV.</h5>
		<h1>Why should you come with us?</h1>
		<h5>Nếu các bạn chưa có người yêu, nhưng bố mẹ lại muốn các bạn dẫn người yêu về thì hãy đến với chúng tôi.<br>Chúng tôi đã đưa ra giải pháp cho các bạn đó là dịch vụ cho thuê người yêu.<br>Khi đến với chúng tôi các bạn sẽ an tâm khi các thông tin của bạn sẽ được bảo mật tuyệt đối.</h5>
	</div>
	
</body>
</html>