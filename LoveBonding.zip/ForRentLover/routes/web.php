<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Schema;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
// Route::get('/', function () {
//     return view('home_user.trangchu');
// });
// ****************************************USER***********************************
Route::get('/', [
    'as' => 'trang-chu',
    'uses' => 'HomeController@getIndexUser'
]);

Route::get('loai-nhan-vien/{gender}', [
	'as' => 'loainhanvien',
	'uses' => 'HomeController@getLoaiNhanVien'
]);

Route::get('tang-dan', [
    'as' => 'tangdan',
    'uses' => 'HomeController@AscPrice'
]);

Route::get('giam-dan', [
    'as' => 'giamdan',
    'uses' => 'HomeController@DescPrice'
]);

Route::get('chi-tiet-nhan-vien/{id}', [
	'as' => 'chitietsanpham',
	'uses' => 'HomeController@getChitietNhanVien'
]);

Route::post('chi-tiet-nhan-vien/{id}', [
    'as' => 'chitietsanpham',
    'uses' => 'HomeController@postReview'
]);
// Route::get('add-to-list/{id}', [
// 	'as' => 'addtolist',
// 	'uses' => 'HomeController@getAddtoList'
// ]);


Route::get('dat-lich/{id}', [
	'as' => 'datLich',
	'uses' => 'HomeController@getBooked'
]);

Route::post('dat-lich/{id}' ,[
	'as'=>'datLich',
	'uses'=>'HomeController@postBooked'
]);

Route::get('lien-he', [
    'as' => 'lienhe',
    'uses' => 'HomeController@getLienHe'
]);

Route::post('lien-he', [
    'as' => 'lienhe',
    'uses' => 'HomeController@postLienHe'
]);


// **************************************LOGIN*****************************
// Dang nhap
Route::get('Sign-In',[
    'as'=>'dangnhap',
    'uses'=>'HomeController@getSignIn'
]);

Route::post('Sign-In',[
    'as'=>'dangnhap',
    'uses'=>'HomeController@postSignIn'
]);

// Dang ki
Route::get('Sign-Up',[
    'as'=>'dangki',
    'uses'=>'HomeController@getSignUp'
]);

Route::post('Sign-Up',[
    'as'=>'dangki',
    'uses'=>'HomeController@postSignUp'
]);

// Search
Route::get('Search',[
    'as'=>'timkiem',
    'uses'=>'HomeController@Search'
]);

// Dang xuat
Route::get('Logout',[
    'as'=>'dangxuat',
    'uses'=>'HomeController@getLogout'
]);

// ***************************************ADMIN**********************************



Route::get('Index-Admin', [
    'as' => 'trang_chu',
    'uses'=> 'HomeController@getIndexAdmin'
]);

Route::get('aboutUs', [
    'as' => 'aboutUs',
    'uses'=> 'HomeController@aboutUs'
]);

Route::get('admin', [
    'as' => 'admin',
    'uses'=> 'HomeController@getIndex'
]);

//*******GET EMPLOYEE******
Route::get('admin/employee', [
    'as' => 'employee',
    'uses'=> 'HomeController@getEmployee'
]);

Route::get('sort', [
    'as' => 'sort',
    'uses'=> 'HomeController@sortEmployee'
]);
//*******ADD EMPLOYEE******

Route::get('admin/insert',[
    'as' => 'insert',
    'uses'=> 'HomeController@viewAddEmployee'
]);

Route::post('admin/insert',[
    'as' => 'insert',
    'uses'=> 'HomeController@AddEmployee'
]);

//*******DELETE EMPLOYEE*****

Route::get('admin/delete/{id}', [
    'as' => 'delete',
    'uses'=> 'HomeController@deleteEmployee'
]);

//*******UPDATE EMPLOYEE*******

Route::get('admin/update/{id}', [
    'as' => 'update',
    'uses'=> 'HomeController@viewUpdateEmployee'
]);

Route::post('admin/update/{id}', [
    'as' => 'update',
    'uses'=> 'HomeController@updateEmployee'
]);

//************GET CUSTOMER*******
Route::get('customer', [
    'as' => 'customer',
    'uses'=> 'HomeController@getCustomer'
]);

Route::get('adminupdate', [
    'as' => 'adminupdate',
    'uses'=> 'HomeController@orderByMonth'
]);

Route::get('sum', [
    'as' => 'sum',
    'uses'=> 'HomeController@getSum'
]);

Route::get('bill', [
    'as' => 'bill',
    'uses'=> 'HomeController@getBill'
]);
//

