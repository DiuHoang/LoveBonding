<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
class TypeEmployeeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // //
        // $faker = Faker\Factory::create();

        // $limit = 3;

        // for ($i = 0; $i < $limit; $i++) {
        //     $gender = $faker->randomElement($array = array('Male','Female','Mixed'));
        // for ($i = 0; $i < $limit; $i++)
        //     DB::table('type_employee')->insert([
        //         'gender'=>  $gender,
        //         'created_at'=> new DateTime(),
        //         'updated_at'=> new DateTime()
        //     ]);
        // }
        DB::table('type_employee')->insert([
            'gender'=> "Male",
            'created_at'=> new DateTime(),
            'updated_at'=> new DateTime()
        ]);
        DB::table('type_employee')->insert([
            'gender'=>"Female",
            'created_at'=> new DateTime(),
            'updated_at'=> new DateTime()
        ]);
        DB::table('type_employee')->insert([
            'gender'=>"Mixed",
            'created_at'=> new DateTime(),
            'updated_at'=> new DateTime()
        ]);
    }
}
