<?php

use App\Bill_Detail;
use Illuminate\Database\Seeder;

use App\Employee;


use Illuminate\Support\Facades\DB;
use App\TypeEmployee;
class EmployeeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        // $faker = Faker\Factory::create();
        // $limit = 10;
        // $typeProduct = TypeEmployee::all()->pluck('id')->toArray();

        // for ($i = 0; $i < $limit; $i++) {
        //     DB::table('employee')->insert([
        //         'name'=> $faker->name,
        //         'id_type'=> $faker->randomElement($typeProduct),
        //         'age'=>$faker->numberBetween(18, 35),
        //         'address'=> $faker->address,
        //         'phone_number'=>$faker->phoneNumber,
        //         'description'=>$faker->text($maxNbChars = 20),
        //         'unit_price'=>$faker->randomDigit,
        //         'image'=>($i + 1).'.jpg',
        //         'created_at'=> new DateTime(),
        //         'updated_at'=> new DateTime()
        //     ]);
        // }

        DB::table('employee')->insert([
            'name'=> 'Hoàng Dịu',
            'id_type'=> 3,
            'age'=> 20,
            'address'=> 'Quảng Bình',
            'phone_number'=> '0395587260',
            'description'=> 'Cute lạc lối nhất hành tinh!',
            'unit_price'=> 100.000,
            'image'=>'diu.jpg',
            'created_at'=> new DateTime(),
            'updated_at'=> new DateTime()
        ]);
        DB::table('employee')->insert([
            'name'=> 'Nguyễn Hoàng',
            'id_type'=> 1,
            'age'=> 23,
            'address'=> 'Quảng Trị',
            'phone_number'=> '0395587260',
            'description'=> 'Đàn ông là phải mạnh mẽ',
            'unit_price'=> 670.000,
            'image'=>'3.jpg',
            'created_at'=> new DateTime(),
            'updated_at'=> new DateTime()
        ]);
        DB::table('employee')->insert([
            'name'=> 'Trần Tuấn',
            'id_type'=> 1,
            'age'=> 27,
            'address'=> 'Quảng Nam',
            'phone_number'=> '0395587260',
            'description'=> 'Cô đơn đã 20 năm',
            'unit_price'=> 320.000,
            'image'=>'10.jpg',
            'created_at'=> new DateTime(),
            'updated_at'=> new DateTime()
        ]);
        DB::table('employee')->insert([
            'name'=> 'Nguyễn Hân',
            'id_type'=> 2,
            'age'=> 13,
            'address'=> 'Đà Nẵng',
            'phone_number'=> '0395587260',
            'description'=> 'Dễ thương và Lạc Lỗi',
            'unit_price'=> 103.200,
            'image'=>'2.jpg',
            'created_at'=> new DateTime(),
            'updated_at'=> new DateTime()
        ]);
        DB::table('employee')->insert([
            'name'=> 'Nga Mai',
            'id_type'=> 3,
            'age'=> 20,
            'address'=> 'Quảng Nam',
            'phone_number'=> '0395587260',
            'description'=> 'Ai biết yêu là gì? Lí do Cô đơn',
            'unit_price'=> 543.900,
            'image'=>'nga.jpg',
            'created_at'=> new DateTime(),
            'updated_at'=> new DateTime()
        ]);
        DB::table('employee')->insert([
            'name'=> 'Quân Hồ',
            'id_type'=> 3,
            'age'=> 20,
            'address'=> 'Quảng Trị',
            'phone_number'=> '0395587260',
            'description'=> 'Nhẹ Nhàng Quyến Rũ',
            'unit_price'=> 23.000,
            'image'=>'quan.jpg',
            'created_at'=> new DateTime(),
            'updated_at'=> new DateTime()
        ]);
        DB::table('employee')->insert([
            'name'=> 'Hoa Huệ',
            'id_type'=> 2,
            'age'=> 18,
            'address'=> 'TP Huế',
            'phone_number'=> '0395587260',
            'description'=> 'Người Con giá Huế ngọt ngào lãng mạn',
            'unit_price'=> 500.000,
            'image'=>'7.jpg',
            'created_at'=> new DateTime(),
            'updated_at'=> new DateTime()
        ]);

    }
}

