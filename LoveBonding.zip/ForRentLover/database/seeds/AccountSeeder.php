<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
class AccountSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('account')->insert([
            'name' => 'Admin',
            'gender' => 'Female',
            'phone_number' => '0395587260',
            'image' => 'avatar5.jpeg',
            'level' => 'admin',
            'email' => 'admin@gmail.com',
            'password' => 'admin123456',
            'repassword' => 'admin123456',
            'created_at'=> new DateTime(),
            'updated_at'=> new DateTime()
        ]);
    }
}
