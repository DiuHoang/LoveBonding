<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEmployeeTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('employee', function (Blueprint $table) {
            $table->id()->unsigned();
            $table->string('name');
            $table->foreignId('id_type')->references('id')->on('type_employee');
            $table->integer('age');
            $table->string('address');
            $table->string('phone_number');
            $table->text('description');
            $table->float('unit_price');
            $table->string('image');
            $table->timestamps(true);
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('employee');
    }
}
