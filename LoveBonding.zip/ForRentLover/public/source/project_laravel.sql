create database laravel_project;
use laravel_project;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";
CREATE TABLE customer (
  id int(10) not null primary key auto_increment,
  name varchar(100),
  gender varchar(10),
  address varchar(100),
  phone_number varchar(20),
  note varchar(200),
  created_at timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  updated_at timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
);
Insert into customer(id,name,gender,address,phone_number,note) values
(1,'Ho Van Quan','nam','Quang Tri','1233434','Chua co nguoi yeu'),
(2,'Hoang Thi Diu','nu','Quang Binh','231134141','Bi cam sung'),
(3,'Mai Thi Nga','nu','Quang Binh','231134141','Co nguoi yeu');

CREATE TABLE account (
  id int(10) not null primary key auto_increment,
  id_cus int(11),
  email varchar(50),
  password varchar(100),
  created_at timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  updated_at timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  FOREIGN KEY(id_cus) REFERENCES customer(id)
);
Insert into account(id,id_cus,email,password) values
(1,1,'quan.ho@gmail.com','Chua co nguoi yeu'),
(2,2,'diu.hoang@gamil.com','Bi cam sung'),
(3,3,'nga.mai@gamil.com','Co nguoi yeu');

CREATE TABLE bill (
  id int(10)  NOT NULL primary key auto_increment,
  id_cus int(11),
  date_book date,
  total float,
  payment varchar(200),
  note varchar(500),
  created_at timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  updated_at timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  FOREIGN KEY(id_cus) REFERENCES customer(id)
);

CREATE TABLE message (
  id int(10)  NOT NULL primary key auto_increment,
  id_cus int(11),
  content text,
  create_at timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  updated_at timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  FOREIGN KEY(id_cus) REFERENCES customer(id)
);
Insert into message(id,id_cus,content) values
(1,1,'Em chua co nguoi yeu'),
(2,2,'Em dang bi cam sung anh oi'),
(3,3,'Em co nguoi yeu roi');

CREATE TABLE employee (
  id int(10)  NOT NULL primary key auto_increment,
  name varchar(100),
  gender varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  description text COLLATE utf8_unicode_ci DEFAULT NULL,
  unit_price float DEFAULT NULL,
  promotion_price float DEFAULT NULL,
  image varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  created_at timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  updated_at timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
);
Insert into employee(id,name,gender,description,unit_price,promotion_price,image) values
(1,'Tong Quan','nam','Rat phong khoang',123,0, 'images/anh1.jpg'),
(2,'Diu Hoang','nu','Rat dien khung',123,110, 'images/anh2.jpg'),
(3,'Mai Nga','nu','Rat ca tinh',123,100, 'images/anh3.jpg');

CREATE TABLE bill_detail (
  id int(10)  NOT NULL primary key auto_increment,
  id_bill int(10) NOT NULL,
  id_employee int(10) NOT NULL,
  hours int(11) NOT NULL,
  price double NOT NULL,
  created_at timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  updated_at timestamp NULL DEFAULT current_timestamp(),
  FOREIGN KEY(id_bill) REFERENCES bill(id),
  FOREIGN KEY(id_employee) REFERENCES employee(id)
);

Select * from customer;
Select * from employee;
Select * from  account;
Select * from  message;