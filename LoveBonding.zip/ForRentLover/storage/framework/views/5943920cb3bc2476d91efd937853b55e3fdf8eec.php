<?php $__env->startSection('content'); ?>

<div class="container">
    <h1 class="page-title">Lien He Voi Chung Toi</h1>
    <form action="" method="post" class="beta-form-checkout">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <div class="row">
            <?php if(Session::has('thb_contact')): ?>
            <div class="alert alert-success"><?php echo e(Session::get('thb_contact')); ?></div>
            <?php endif; ?>
            <div class="row" style="margin-left: 15%;">
                <div>
                    <label>Ten cua Ban</label>
                    <input class="form-control" style="width: 700px; margin-bottom: 20px;" placeholder="Your name"
                        name="name" />
                    <label>So Dien Thoai Cua Ban</label>
                    <input class="form-control" style="margin-bottom: 20px;" placeholder="Your phone number"
                        name="phone_number" />
                    <label>Dia Chi Email Cua Ban</label>
                    <input class="form-control" style="margin-bottom: 20px;" placeholder="Your email" name="email" />
                    <label>Nhap Noi Dung</label>
                    <textarea class="form-control" style="margin-bottom: 20px;" placeholder="Ban Dang Co Thac Mac Gi?"
                        name="content"></textarea>
                    <button class="btn btn-primary" style="margin-bottom: 20px;">Contact</button>
                </div>

            </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\ForRentLover\resources\views/home/lienhe.blade.php ENDPATH**/ ?>