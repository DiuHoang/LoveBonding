<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculator</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

</head>
<body>
    <h1>Tinh Tong Hai So Nguyen</h1>
    <form action="" method="post">
        <?php echo csrf_field(); ?> 
       
    <div class="form-group">
        <label for="exampleInputNumberA">Enter Number A</label>
        <input type="text" class="form-control" name="numberA" placeholder="Number A">
    </div>
    <div class="form-group">
        <label for="exampleInputNumberB">Enter Number B</label>
        <input type="text" class="form-control" name="numberB" placeholder="Number B">
    </div>
    <p>  <?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> </p>
    <button type="submit" class="btn btn-primary">Sum</button>
    <h2><?php if(isset($sum)): ?> <?php echo e($sum); ?> <?php endif; ?></h2>
    </form>
    
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\online_web\resources\views/Tinhtong.blade.php ENDPATH**/ ?>