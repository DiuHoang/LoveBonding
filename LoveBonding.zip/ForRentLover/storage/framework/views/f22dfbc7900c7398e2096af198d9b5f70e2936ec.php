<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hotel</title>
    <link rel="stylesheet" type="text/css" href="Style/news.css"> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

</head>
<body>
    <h3>Hotel</h3>
    <form action="">
    <?php echo csrf_field(); ?>
    <div> <?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
    <div class="form-group">
        <label for="exampleInputName">Name Room</label>
        <input type="text" class="form-control" id="exampleInputName"  placeholder="Enter name">
    </div>
    <div class="form-group">
        <input type="file" name="myFile" id="myFile">
    </div>
    <div class="form-group">
        <label for="exampleInputNumber">Number Room</label>
        <input type="text" class="form-control" id="exampleInputNumber"  placeholder="Enter number">
    </div>
    <div class="form-group">
        <label for="exampleInputTyperooom">Typer Room</label>
        <input type="text" class="form-control" id="exampleInputTyperooom"  placeholder="Enter typeroom">
    </div>
    <div class="form-group">
        <label for="exampleInputArea">Area Room</label>
        <input type="text" class="form-control" id="exampleInputArea"  placeholder="Enter area">
    </div>
    <div class="form-group">
        <label for="exampleInputPrice">Price Room</label>
        <input type="number" class="form-control" id="exampleInputPrice"  placeholder="Enter price">
    </div>
    <button type="submit" class="btn btn-primary">Add</button>
    </form>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\KT.HoangThiDiu\resources\views/room.blade.php ENDPATH**/ ?>