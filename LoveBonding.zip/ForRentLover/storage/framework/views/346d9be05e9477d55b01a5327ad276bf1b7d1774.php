
<?php $__env->startSection('content'); ?>
<!-- Content -->
<div class="container">
    <div class="et_pb_module et_pb_text et_pb_text_6  et_pb_text_align_left et_pb_bg_layout_light">
        <div class="et_pb_text_inner">
            <h1 style="text-align: center; border-bottom: 2px solid orange; margin-bottom: 40px">Popular The Faces</h1>
        </div>
    </div>
    <div class="row">
        <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employees): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 col-sm-6">
            <div class="product-grid3">
                <div class="product-image3">

                    <a href="<?php echo e(route('chitietsanpham', $employees->id)); ?>">
                        <img class="pic-1" src="image/product/<?php echo e($employees->image); ?>">
                        <img class="pic-2" src="image/product/<?php echo e($employees->image); ?>">
                    </a>
                    <ul class="social">
                        <li><a href="#"><i class="fa fa-comments"></i></a></li>

                        <li><a href="<?php echo e(route('addtolist', $employees->id)); ?>"><i class="fa fa-calendar-o"></i></a>
                        </li>
                       
                    </ul>
                    <span class="product-new-label">New</span>
                </div>
                <div class="product-content">
                    <h3 class="title"><a href="#"><?php echo e($employees->name); ?></a></h3>
                    <div class="price">
                        <?php echo e($employees->unit_price); ?> $/ Date
                        <!-- <span>$75.00</span> -->
                    </div>
                    <ul class="rating">
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star disable"></li>
                        <li class="fa fa-star disable"></li>
                    </ul>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>
</div>
<nav class="navbar navbar-default">
    <div class="container">
        <div class="collapse navbar-collapse" id="navcol-1">
            <ul class="nav navbar-nav navbar-right">
                <li class="active" role="presentation"><a href="#">First Item</a></li>
                <li role="presentation"><a href="#">Second Item</a></li>
                <li role="presentation"><a href="#">Third Item</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="testimonials-clean">
    <div class="container">
        <div class="intro">
            <h2 class="text-center">ABOUT US </h2>
            <p class="text-center">Our customers love us! Read what they have to say below. Aliquam sed justo ligula.
                Vestibulum nibh erat, pellentesque ut laoreet vitae.</p>
        </div>
        <div class="row people">
            <div class="col-md-6 col-lg-4 item">
                <div class="box">
                    <p class="description">Aenean tortor est, vulputate quis leo in, vehicula rhoncus lacus. Praesent
                        aliquam in tellus eu gravida. Aliquam varius finibus est.</p>
                </div>
                <div class="author"><img class="rounded-circle" src="image/product/quan.jpg">
                    <h5 class="name">Tong Quan</h5>
                    <p class="title">CEO of Company Inc.</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 item">
                <div class="box">
                    <p class="description">Praesent aliquam in tellus eu gravida. Aliquam varius finibus est, et
                        interdum justo suscipit id.</p>
                </div>
                <div class="author"><img class="rounded-circle" src="image/product/diu.jpg">
                    <h5 class="name">Hoang Diu</h5>
                    <p class="title">Founder of Style Co.</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 item">
                <div class="box">
                    <p class="description">Aliquam varius finibus est, et interdum justo suscipit. Vulputate quis leo
                        in, vehicula rhoncus lacus. Praesent aliquam in tellus eu.</p>
                </div>
                <div class="author"><img class="rounded-circle" src="image/product/nga.jpg">
                    <h5 class="name">Mai Nga</h5>
                    <p class="title">Owner of Creative Ltd.</p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ForRentLover\resources\views/home/trangchu.blade.php ENDPATH**/ ?>