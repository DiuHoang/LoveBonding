<!DOCTYPE html>
<html>
<head>
	<title>Update</title>

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/all.css" integrity="sha384-/rXc/GQVaYpyDdyxK+ecHPVYJSN9bmVFBvjA/9eOB+pb3F2w2N6fc5qB9Ew5yIns" crossorigin="anonymous">

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css')); ?>/insertStyle.css" >
</head>
<body>
	<center>
		<div class="insert">
			<div class="left">
				<img src="" width="200">
			</div>
			<div class="container">
				<h1>Update New Employee</h1>
				<form method="post" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
				    <br>
				    <label>Name</label>
				    <input type="" class="form-control" value="<?php echo e($employee->name); ?>" placeholder="Name" name="name">
				    <br>
				    <label>Address</label>
				    <input type="" class="form-control" value="<?php echo e($employee->address); ?>" placeholder="Address" name="address">
				    <br>
				    <label>Phone Number</label>
				    <input type="" class="form-control" value="<?php echo e($employee->phone_number); ?>" placeholder="Phone Number" name="phone_number">
				    <br>
				    <label>Age</label>
				    <input type="" class="form-control" value="<?php echo e($employee->age); ?>" placeholder="Age" name="age">
				    <br>
				    <label>Gender</label>
				    <select class="form-control" name="gender" id="sel1">
				    	<?php if($employee->id_type == 'male'): ?>{
							<option value="1" selected>Male</option>
							<option value="2">Female</i></option>
							<option value="3">Mixed</i></option>
				    	}<?php elseif($employee->id_type == 'female'): ?>{
				    		<option value="1" >Male</option>
				    		<option value="2" selected>Female</i></option>
				    		<option value="3">Mixed</i></option>
				    	}<?php else: ?>{
				    		<option value="1" >Male</option>
				    		<option value="2" >Female</i></option>
				    		<option value="3" selected>Mixed</i></option>
				    	}
				    	<?php endif; ?>
			      	</select>
				    <br>
				    <label>Description</label>
				    <input type="" class="form-control" value="<?php echo e($employee->description); ?>" placeholder="description" name="description">
				    <br>
				    <label>Price</label>
				    <input type="" class="form-control" value="<?php echo e($employee->unit_price); ?>" placeholder="price" name="price">
				    <br>
				    <label>Avatar</label>
				    <input type="file" class="form-control" value="<?php echo e($employee->image); ?>" name="newFile" id="myFile">
			    	<br>
				    <button type="submit" class="btn btn-success" name="sub">Submit</button>
				</form>

			</div>
		</div>
	</center>
</body>
</html>
<?php /**PATH C:\Users\admin\Desktop\Diu Hoang\18_08_2020_ForRentLover\ForRentLover\resources\views/home_admin/update.blade.php ENDPATH**/ ?>