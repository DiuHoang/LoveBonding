<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('trang_chu')); ?>"><button class="btn btn-dark">Back Home</button></a>

<div class="container">
    <center>
        <table class="table">
            <thead class="table-info">
                <tr>
                    <th>Tháng</th>
                    <th>Số tiền kiếm được</th>
                    <th>Số lượng đơn hàng</th>
                </tr>
            </thead>
            <?php $__currentLoopData = $sum_bill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tbody>
                <tr>
                    <td><?php echo $sum['month']; ?></td>
                    <td><?php echo $sum['s']; ?> $</td>
                    <td><?php echo $sum['c']; ?> đơn</td>
                </tr>
            </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </center>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\Desktop\Diu Hoang\18_08_2020_ForRentLover\ForRentLover\resources\views/home_admin/tien.blade.php ENDPATH**/ ?>