<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row" style="margin-left: 15%;">
        <h1 class="page-title">Liên hệ dịch vụ thuê người yêu</h1>

        <!-- <div id="hotline">"Hotline: "<a href="tel:0395587260"> 0395 587 260</a></div> -->
        <form action="" method="post" class="beta-form-checkout">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <div class="row">
            <?php if(Session::has('thb_datlich')): ?>
            <div class="alert alert-success"><?php echo e(Session::get('thb_datlich')); ?></div>
            <?php endif; ?>
                <div class="region.region-content">
                    <!-- Phan thong tin cua khach hang -->
                    <fieldset class="panel panel-default form-wrapper">
                        <legend class="panel-heading">
                            <span class="panel-title fieldset-legend">Thong Tin Khach Hang</span>
                        </legend>
                        <div class="panel-body">
                            <div class="form-item form-item-customer-name form-type-textfield form-group">
                                <label class="control-label">Ho Va Ten</label>
                                <span class="form-required" title="Trường dữ liệu này là bắt buộc.">*</span>
                                <input class="form-control form-text required" name="name" />
                                <div class="help-block">Vui lòng nhập tên của bạn để tiện liên hệ.</div>
                            </div>
                            <div class="form-item form-item-customer-gender form-type-radios form-group">
                                <label class="control-label">Gioi Tinh</label>
                                <span class="form-required" title="Trường dữ liệu này là bắt buộc.">*</span>
                                <div>
                                    <!-- Default inline 1-->
                                    <div class="custom-control custom-radio custom-control-inline">
                                        <input type="radio" class="custom-control-input" id="Male" name="gender"
                                            value="Male" checked="checked">
                                        <label class="custom-control-label" for="Male">Nam</label>
                                    </div>

                                    <!-- Default inline 2-->
                                    <div class="custom-control custom-radio custom-control-inline">
                                        <input type="radio" class="custom-control-input" id="Female" name="gender"
                                            value="Female">
                                        <label class="custom-control-label" for="Female">Nu</label>
                                    </div>
                                </div>
                            </div>
                            <div class="form-item form-item-appointment-city form-type-select form-group"
                                style="margin-top: 15px;">
                                <label class="control-label" for="edit-appointment-city">Địa điểm tại
                                    <span class="form-required" title="Trường dữ liệu này là bắt buộc.">*</span>
                                </label>
                                <div>
                                    <select class="selectpicker" style="width: 700px;" name="address">
                                        <option value="Da nang">Da Nang</option>
                                        <option value="Ha Noi">Ha Noi</option>
                                        <option value="TP Ho Chi Minh">TP Ho Chi Minh</option>
                                        <option value="Quang Binh">Quang Binh</option>
                                        <option value="Quang Tri">Quang Tri</option>
                                        <option value="Quang Nam">Quang Nam</option>
                                        <option value="Binh Dinh">Binh Dinh</option>
                                        <option value="Quang Ngai">Quang Ngai</option>
                                        <option value="Hue">Hue</option>
                                    </select>

                                </div>
                            </div>
                            <div class="form-item form-item-customer-name form-type-textfield form-group"
                                style="margin-top: 15px;">
                                <label class="control-label">Dien Thoai</label>
                                <span class="form-required" title="Trường dữ liệu này là bắt buộc.">*</span>
                                <input class="form-control form-text required" name="phone" />
                                <div class="help-block">Vui lòng nhập so dien thoai của bạn để tiện liên hệ.</div>
                            </div>
                            <div class="form-item form-item-customer-name form-type-textfield form-group">
                                <label class="control-label">Ghi Chu</label>
                                <textarea class="form-control form-text required" name="notes"></textarea>
                                <div class="help-block">Neu Co Bat Ki Thac Mac Gi.</div>
                            </div>
                        </div>
                    </fieldset>
                    <hr style="border: 1px solid red;">
                    <!-- Phan Thong tin cua nhan vien da duoc chon -->
                    <fieldset class="panel panel-default form-wrapper">
                        <legend class="panel-heading">
                            <span class="panel-title fieldset-legend">Nhan Vien Ban Da Chon</span>
                        </legend>
                        <div class="panel-body">
                            <div class="col-md-3 col-sm-6">
                                <div class="product-grid3">
                                    <div class="product-image3">
                                        <a href="#">
                                            <img class="pic-1" src="image/product/<?php echo e($employee->image); ?>">
                                            <img class="pic-2" src="image/product/<?php echo e($employee->image); ?>">
                                        </a>
                                    </div>
                                    <div class="product-content">
                                        <h3 class="title"><a href="#"><?php echo e($employee->name); ?></a></h3>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </fieldset>
                    <hr style="border: 1px solid red;">

                    <!-- Thong tin yeu cau tu Admin -->
                    <fieldset class="panel panel-default form-wrapper">
                        <legend class="panel-heading">
                            <span class="panel-title fieldset-legend">Thoi Gian / Thanh Toan / Muc Dich</span>
                        </legend>
                        <div class="panel-body">
                            <div class="form-item form-item-customer-name form-type-textfield form-group">
                                <label class="control-label">Ngay Dat Lich</label>
                                <span class="form-required" title="Trường dữ liệu này là bắt buộc.">*</span>
                                <input class="form-control form-text required" name="check_in" type="datetime-local" />
                                <div class="help-block">Vui lòng chọn ngày trong tương lai.</div>
                            </div>
                            <div class="form-item form-item-customer-name form-type-textfield form-group">
                                <label class="control-label">Bao Nhiêu Giờ</label>
                                <input name="hours" placeholder="5$/hour" type="number" onkeyup="totalCal(this);" />

                                <script>
                                function totalCal(inputElement) {
                                    var hour = inputElement.value;
                                    var target = document.getElementById('sum');
                                    if (target != null) {
                                        target.innerHTML = hour * <?php echo e($employee->unit_price); ?> + "$";
                                    }
                                    document.getElementById('kq').value = hour * <?php echo e($employee->unit_price); ?>;
                                }
                                </script>

                                <label class="control-label">Tong Tien:
                                    <input type="text" name="totalPrice" value="" id="kq" hidden />
                                    <span style="color: red;" name="totalPrice" id="sum" value="this"></span>
                                </label>
                            </div>
                            <div class="form-item form-item-customer-name form-type-textfield form-group">
                                <label class="control-label">Hình thức thanh toán</label>
                                <span class="form-required" title="Trường dữ liệu này là bắt buộc.">*</span>
                                <div>
                                    <select class="selectpicker" style="width: 700px;" name="payment">
                                        <option value="COD">Thanh toán khi gap nhan vien</option>
                                        <option value="ATM">Chuyển khoản</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-item form-item-customer-name form-type-textfield form-group">
                                <label class="control-label">Muc Dich</label>
                                <span class="form-required" title="Trường dữ liệu này là bắt buộc.">*</span>
                                <div>
                                    <!-- Default unchecked -->
                                    <div class="custom-control custom-radio">
                                        <input type="radio" class="custom-control-input" id="diChoi" name="note" value="Cùng đi chơi / đi ăn
                                            /trò chuyện tâm sự" checked="checked" />
                                        <label class="custom-control-label" for="diChoi">Cùng đi chơi / đi ăn
                                            /trò chuyện tâm sự</label>
                                    </div>
                                    <div class="custom-control custom-radio">
                                        <input type="radio" class="custom-control-input" id="sinhNhat" name="note"
                                            value="Dự sinh nhật / dự tiệc">
                                        <label class="custom-control-label" for="sinhNhat">Dự sinh nhật / dự
                                            tiệc</label>
                                    </div>
                                    <div class="custom-control custom-radio">
                                        <input type="radio" class="custom-control-input" id="giaDinh" name="note"
                                            value="Thăm gia đình, ra mắt bố mẹ">
                                        <label class="custom-control-label" for="giaDinh">Thăm gia đình, ra mắt bố
                                            mẹ</label>
                                    </div>
                                    <div class="custom-control custom-radio">
                                        <input type="radio" class="custom-control-input" id="duLich" name="note"
                                            value="Đi du lịch, chơi dã ngoại / picnic">
                                        <label class="custom-control-label" for="duLich">Đi du lịch, chơi dã ngoại /
                                            picnic</label>
                                    </div>
                                    <div class="custom-control custom-radio">
                                        <input type="radio" class="custom-control-input" id="huongDanVien" name="note"
                                            value="Hướng dẫn viên địa phương">
                                        <label class="custom-control-label" for="huongDanVien">Hướng dẫn viên địa
                                            phương</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </fieldset>
                    <hr style="border: 1px solid red;">
                    <fieldset>
                        <button class="btn btn-success">Gui Yeu Cau</button>
                    </fieldset>
                </div>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\Desktop\Diu Hoang\18_08_2020_ForRentLover\ForRentLover\resources\views/home_user/datLich.blade.php ENDPATH**/ ?>