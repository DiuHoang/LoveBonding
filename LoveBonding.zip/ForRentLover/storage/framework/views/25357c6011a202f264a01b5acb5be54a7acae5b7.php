<?php $__env->startSection('content'); ?>
<div class="container">
	<form class="form_resgister" action="<?php echo e(route('dangki')); ?>" method="post">
		<?php echo csrf_field(); ?>
		<h2>FOR RENT LOVER</h2>
		<div class="inputs">
			<label>Email</label>
			<input type="email" name="email" placeholder="Email">

			<label>User Name</label>
			<input type="text" name="name" placeholder="Username">

            <label>Phone Number</label>
			<input type="text" name="phonenumber" placeholder="Phone Number">

            <label>Image</label>
			<input type="file" name="image" placeholder="Phone Number">

            <label>Gender</label>
			<select
                 name="gender">
                <option value="male">Male</option>
                <option value="female">Female</option>
			</select>

			<label style="margin-top:10px;">Password</label>
			<input type="password" name="password" placeholder="Password">

			<label>Confirm Password</label>
			<input type="password" name="repassword" placeholder="confirm-password">

			<?php if(count($errors) >0): ?>
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li class="text-danger"> <center><?php echo e($error); ?></center></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
     		<?php endif; ?>

		</div>
		<button id="button_register">SIGN UP</button>
	</form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\Desktop\Diu Hoang\15_08_2020 - ForRentLover\ForRentLover\resources\views/home/dangki.blade.php ENDPATH**/ ?>