<script src="public/assets/js/jquery.min.js"></script>
<script src="public/assets/bootstrap/js/bootstrap.min.js"></script>
<script src="assets/js/jquery.min.js"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.8.2/js/lightbox.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/js/swiper.jquery.min.js"></script>
<script src="assets/js/Simple-Slider.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
    <script src="assets/js/agency.js"></script>

    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
<?php /**PATH C:\Users\admin\Desktop\Diu Hoang\18_08_2020_ForRentLover\ForRentLover\resources\views/home_user/script.blade.php ENDPATH**/ ?>