<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dien Tich Tam Giac Va Tu Giac</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
</head>
<body>
    <h1>Tinh Dien Tich Hinh Tam Giac Va Tu Giac</h1>
    <form action="" method="get">
        <?php echo csrf_field(); ?> 
    <div class="form-group">
        <label for="exampleInputCanhA">Nhap canh thu nhat</label>
        <input type="number" class="form-control" name="canhA" placeholder="Nhap canh a" style="width: 300px">
    </div>
    <div class="form-group">
        <label for="exampleInputCanhB">Nhap canh thu hai</label>
        <input type="number" class="form-control" name="canhB" placeholder="Nhap canh b" style="width: 300px">
    </div>
    <div class="form-group">
        <label for="exampleInputCanhC">Nhap canh thu ba</label>
        <input type="number" class="form-control" name="canhC" placeholder="Nhap canh c" style="width: 300px">
    </div>
    
    <button type="submit" class="btn btn-primary">Thuc Hien</button>
   
    <h5> <?php echo e($tamGiac); ?></h5>
    <h5> <?php echo e($hinhChuNhat); ?></h5>
    <h5> <?php echo e($hinhVuong); ?></h5>
    </form>
    
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\online_web\resources\views/DienTichTamTuGiac.blade.php ENDPATH**/ ?>