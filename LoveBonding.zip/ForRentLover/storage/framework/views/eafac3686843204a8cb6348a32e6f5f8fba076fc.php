<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="inner-header">
        <div class="container">
            <div class="pull-left">
                <h3 class="inner-title"></h3>
            </div>
            <div class="pull-right">
                <div class="beta-breadcrumb font-large">
                    <a href="<?php echo e(route('trang-chu')); ?>">Trang chủ</a> / <span>Thông tin chi tiết nhân viên</span>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
    <ol class="breadcrumb">
        <h1 style="text-align: center; border-bottom: 2px solid orange; margin-bottom: 40px">Information of
            <?php echo e($nhanvien->name); ?></h1>

    </ol>

    <div class="row product">
        <div class="product-grid3">
            <div class="product-image3">
                <img class="pic-1" src="image/product/<?php echo e($nhanvien->image); ?>">
                <img class="pic-2" src="image/product/<?php echo e($nhanvien->image); ?>">
            </div>
        </div>
        <div class="col-md-7" style="padding: 30px;">
            Ho Ten: <h3><?php echo e($nhanvien->name); ?></h3>
            Gioi Tinh:<h3> <?php echo e($nhanvien->id_type); ?></h3>
            <h3 style="color:red;"><?php echo e($nhanvien->unit_price); ?>$ / Date</h3>
            Date Time
            <br>
            <input type="datetime-local" />
            <br><br>
            <select>
                <option value="" selected="">Ban dat lich bao nhieu gio?</option>
                <option value="1">1 Tieng</option>
                <option value="2">2 Tieng</option>
                <option value="3">3 Tieng</option>
                <option value="4">4 Tieng</option>
                <option value="5">5 Tieng</option>
            </select>
            <br><br>
            <button type="button" class="btn btn-success">Contact</button>
            <button type="button" class="btn btn-success">Dat Lich</button>
        </div>
    </div>
    <div class="page-header" style="margin-top: 20px;">
        <h3 style="color: orange">Product Details</h3>
    </div>
    <p><?php echo e($nhanvien->description); ?></p>

    <!-- list -->
    <!-- //list -->
    <div class="page-header" style="margin-top: 20px;">
        <h3 style="color: orange">Reviews 4.9/5</h3>
    </div>
    <div class="media">
        <div class="media-body">
            <h4 class="media-heading">Love this!</h4>
            <div><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i
                    class="fa fa-star"></i><i class="fa fa-star-half"></i></div>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus nisl ac diam feugiat, non
                vestibulum libero posuere. Vivamus pharetra leo non nulla egestas, nec malesuada orci finibus. </p>
            <p><span class="reviewer-name"><strong>John Doe</strong></span><span class="review-date">7 Oct 2015</span>
            </p>
        </div>
    </div>
    <div class="media">
        <div class="media-body">
            <h4 class="media-heading">Fantastic product</h4>
            <div><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i
                    class="fa fa-star"></i><i class="fa fa-star"></i></div>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus nisl ac diam feugiat, non
                vestibulum libero posuere. Vivamus pharetra leo non nulla egestas, nec malesuada orci finibus. </p>
            <p><span class="reviewer-name"><strong>Jane Doe</strong></span><span class="review-date">7 Oct 2015</span>
            </p>
        </div>
    </div>
    <form action="" method="post">
        <?php echo csrf_field(); ?>
        <div class="page-header" style="margin-top: 20px;">
            <ul> <button class="btn btn-primary">Write a
                    review</button>
                <li>
                    <textarea class="form-control" type="='text" placeholder="Ban Dang Suy Nghi Gi?"
                        name="comment"></textarea>
                    <button class="btn btn-success">Comment</button>

                </li>
            </ul>
            </h3>
        </div>
        <div>
            <h1><?php echo e(($message->content)); ?></h1>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\Desktop\Diu Hoang\15_08_2020 - ForRentLover\ForRentLover\resources\views/home/chitiet_NhanVien.blade.php ENDPATH**/ ?>