<?php $__env->startSection('content'); ?>
<!-- cua tui -->
<div class="container">
    <div class="pull-left">
        <h6 class="inner-title"></h6>
    </div>
    <div class="pull-right">
        <div class="beta-breadcrumb font-large">
            <a href="<?php echo e(route('trang-chu')); ?>">Trang Chu</a> / <span>Loại nhan vien</span>
        </div>
    </div>
    <div class="space50">&nbsp;</div>
    <div class="clearfix"></div>

    <!-- sp chinh -->
    <div class="row">
        <div class="space50">&nbsp;</div>
        <div>
            <h4>Nhan Vien chinh</h4>

            <p class="pull-left">Tìm thấy <?php echo e(count($emp_theoloai)); ?> Nhan Vien</p>
            <div class="clearfix"></div>
        </div>

        <?php $__currentLoopData = $emp_theoloai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 col-sm-6">
            <div class="product-grid3">
                <div class="product-image3">

                    <a href="<?php echo e(route('chitietsanpham', $emp->id)); ?>">
                        <img class="pic-1" src="image/product/<?php echo e($emp->image); ?>">
                        <img class="pic-2" src="image/product/<?php echo e($emp->image); ?>">
                    </a>
                    <ul class="social">
                        <li><a href="<?php echo e(route('lienhe')); ?>"><i class="fa fa-comments"></i></a></li>

                        <li><a href="<?php echo e(route('datLich', $emp->id)); ?>"><i class="fa fa-calendar-o"></i></a>
                        </li>

                    </ul>
                    <span class="product-new-label">New</span>
                </div>
                <div class="product-content">
                    <h3 class="title"><a href="#"><?php echo e($emp->name); ?></a></h3>
                    <div class="price">
                        <?php echo e($emp->unit_price); ?> $/ Date
                        <!-- <span>$75.00</span> -->
                    </div>
                    <ul class="rating">
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star disable"></li>
                        <li class="fa fa-star disable"></li>
                    </ul>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="space50">&nbsp;</div>
    </div>
    <!-- sp khac -->
    <div class="row">
        <div class="space50">&nbsp;</div>

        <div class="space50">&nbsp;</div>

        <div>
            <h4>Nhan Vien khác</h4>

            <p class="pull-left">Tìm thấy <?php echo e(count($emp_khac)); ?> Nhan Vien</p>
            <div class="clearfix"></div>
        </div>

        <?php $__currentLoopData = $emp_khac; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp_k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 col-sm-6">
            <div class="product-grid3">
                <div class="product-image3">

                    <a href="<?php echo e(route('chitietsanpham', $emp_k->id)); ?>">
                        <img class="pic-1" src="image/product/<?php echo e($emp_k->image); ?>">
                        <img class="pic-2" src="image/product/<?php echo e($emp_k->image); ?>">
                    </a>
                    <ul class="social">
                        <li><a href="<?php echo e(route('lienhe')); ?>"><i class="fa fa-comments"></i></a></li>

                        <li><a href="<?php echo e(route('datLich', $emp_k->id)); ?>"><i class="fa fa-calendar-o"></i></a>
                        </li>

                    </ul>
                    <span class="product-new-label">New</span>
                </div>
                <div class="product-content">
                    <h3 class="title"><a href="#"><?php echo e($emp_k->name); ?></a></h3>
                    <div class="price">
                        <?php echo e($emp_k->unit_price); ?> $/ Date
                        <!-- <span>$75.00</span> -->
                    </div>
                    <ul class="rating">
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star disable"></li>
                        <li class="fa fa-star disable"></li>
                    </ul>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\ForRentLover\resources\views/home/loaiNhanVien.blade.php ENDPATH**/ ?>