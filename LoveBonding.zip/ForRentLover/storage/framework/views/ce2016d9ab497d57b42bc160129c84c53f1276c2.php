<div>
<!--  -->
<script>
    var msg = '<?php echo e(Session::get('alert')); ?>';
    var exist = '<?php echo e(Session::has('alert')); ?>';
    if(exist){
      alert(msg);
    }
</script>
    <div class="header-blue">
        <nav class="navbar navbar-light navbar-expand-md navigation-clean-search">
            <div class="container-fluid"><a class="navbar-brand" href="#">LOGO</a><button data-toggle="collapse"
                    class="navbar-toggler" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span
                        class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navcol-1">
                    <ul class="nav navbar-nav">
                        <li class="nav-item" role="presentation"><a class="nav-link" href="<?php echo e(route('trang-chu')); ?>">TRANG
                                CHU</a></li>
                        <li class="nav-item dropdown"><a class="dropdown-toggle nav-link" data-toggle="dropdown"
                                aria-expanded="false" href="#">DANH MUC </a>
                            <ul>
                                <div class="dropdown-menu" role="menu">

                                    <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="dropdown-item"><a href="<?php echo e(route('loainhanvien' , $loai->id)); ?>"><?php echo e($loai->gender); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </ul>
                        </li>
                    </ul>
                    <form class="form-inline mr-auto" target="_self">
                        <div class="input-group">
                        
                            <input type="text" class="form-control" name="search" placeholder="Search this blog">
                            <div class="input-group-append">
                                <button class="btn btn-secondary" type="submit">
                                    <i class="fa fa-search"></i>
                                </button>
                            </div>
                            
                        </div>
                    </form>
                    <?php if(session('infor')): ?>
                        <span style="background-color:brown">Xin Chao <?php echo e(Session::get('infor')[0]->name); ?></span> &emsp;
                        <a class="btn btn-light action-button" role="button" href="<?php echo e(route('dangxuat')); ?>">Dang Xuat</a>
                    <?php else: ?>
                        <span class="navbar-text"> <a class="login" href="<?php echo e(route('dangnhap')); ?>">Dang Nhap</a></span>
                        <a class="btn btn-light action-button" role="button" href="<?php echo e(route('dangki')); ?>">Dang Ki</a>
                    <?php endif; ?>
                </div>
            </div>
        </nav>
    </div>
</div>
<!-- Slide -->
<div class="header-image"
    style="background-image: url('image/slide/header2.jpg'); background-position: center; height: 500px; width: 100%; background-size: cover; background-repeat: no-repeat; margin-bottom: 20px">
    <p style="margin-left: 100px; padding-top: 60px; font-size: 50px;color:white">Welcome to our Studio</p>
    <h1 style="margin-left: 100px; padding-top: 10px; font-weight: bold; font-size: 60px">IT'S NICE MEET YOU</h1>
    <a href="<?php echo e(route('lienhe')); ?>"><button style="box-shadow: 0 0 0 .2rem rgba(221,183,52,.5); color: #212529;
        background-color: #fec503;
        border-color: #f3bd01; margin-left: 5%; margin-top: 20px; width: 150px">Tell Us More
        </button></a>
</div>
<?php /**PATH C:\Users\admin\Desktop\Diu Hoang\18_08_2020_ForRentLover\ForRentLover\resources\views/home_user/header.blade.php ENDPATH**/ ?>