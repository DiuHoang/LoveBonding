<?php $__env->startSection('content'); ?>

<div class="container">
    <h1 class="page-title">Ban co phan hoi gi cho chung toi</h1>
    <div class="page-header" style="margin-top: 20px;">
        <h3 style="color: orange">Reviews 4.9/5</h3>
    </div>
    <div class="media">
        <div class="media-body">
            <h4 class="media-heading">Love this!</h4>
            <div>
                <i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i
                    class="fa fa-star"></i><i class="fa fa-star-half"></i></div>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus nisl ac diam feugiat, non
                vestibulum libero posuere. Vivamus pharetra leo non nulla egestas, nec malesuada orci finibus. </p>
            <p><span class="reviewer-name"><strong style="color: red;">John Doe</strong></span><span
                    class="review-date">7 Oct 2015</span>
            </p>
        </div>
    </div>
    <div class="media">
        <div class="media-body">
            <h4 class="media-heading">Fantastic product</h4>
            <div><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i
                    class="fa fa-star"></i><i class="fa fa-star"></i></div>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus nisl ac diam feugiat, non
                vestibulum libero posuere. Vivamus pharetra leo non nulla egestas, nec malesuada orci finibus. </p>
            <p><span class="reviewer-name"><strong style="color: red;">Jack Do</strong></span><span
                    class="review-date">7 Oct 2015</span>
            </p>
        </div>
    </div>
    <div class="media">
        <div class="media-body">
            <h4>Beautifull</h4>
            <div>
                <i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i
                    class="fa fa-star"></i><i class="fa fa-star-half"></i></div>
                <p><?php echo e($message->content); ?></p>
                <p><span class="reviewer-name"><strong style="color: red;">Account's name</strong></span><span
                    class="review-date"></span>
                </p>
        </div>
    </div>
</div>
<div>
    <form>
        <div>
            <label>Viet Review tai day</label>
            <textarea class="form-control" style="margin-bottom: 20px;" placeholder="Ban Dang Suy Nghi Gi?"
                name="content"></textarea>
            <button class="btn btn-primary" style="width: 500px; margin-bottom: 20px;">Comment</button>
        </div>
    </form>

</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\ForRentLover\resources\views/home/review.blade.php ENDPATH**/ ?>