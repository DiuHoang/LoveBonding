<div>
    <div class="header-blue">
        <nav class="navbar navbar-light navbar-expand-md navigation-clean-search">
            <div class="container-fluid"><a class="navbar-brand" href="#">LOGO</a><button data-toggle="collapse"
                    class="navbar-toggler" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span
                        class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navcol-1">
                    <ul class="nav navbar-nav">
                        <li class="nav-item" role="presentation"><a class="nav-link" href="<?php echo e(route('trang-chu')); ?>">TRANG
                                CHU</a></li>
                        <li class="nav-item dropdown"><a class="dropdown-toggle nav-link" data-toggle="dropdown"
                                aria-expanded="false" href="#">DANH MUC </a>
                            <div class="dropdown-menu" role="menu"><a class="dropdown-item" role="presentation"
                                    href="#">Danh Sach Yeu Thich</a><a class="dropdown-item" role="presentation"
                                    href="#">Second
                                    Item</a><a class="dropdown-item" role="presentation" href="#">Third Item</a></div>
                        </li>
                    </ul>
                    <form class="form-inline mr-auto" target="_self">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Search this blog">
                            <div class="input-group-append">
                                <button class="btn btn-secondary" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                    <span class="navbar-text"> <a class="login" href="#">Log In</a></span>
                    <a class="btn btn-light action-button" role="button" href="#">Sign Up</a>

                </div>
            </div>
        </nav>
    </div>
</div>
<!-- Slide -->
<div class="header-image"
    style="background-image: url('image/slide/header2.jpg'); background-position: center; height: 500px; width: 100%; background-size: cover; background-repeat: no-repeat; margin-bottom: 20px">
    <p style="margin-left: 100px; padding-top: 60px; font-size: 50px;color:white">Welcome to our Studio</p>
    <h1 style="margin-left: 100px; padding-top: 10px; font-weight: bold; font-size: 60px">IT'S NICE MEET YOU</h1>
    <button style="box-shadow: 0 0 0 .2rem rgba(221,183,52,.5); color: #212529;
        background-color: #fec503;
        border-color: #f3bd01; margin-left: 5%; margin-top: 20px; width: 150px">Tell Us More
    </button>
</div><?php /**PATH C:\xampp\htdocs\laravel\ForRentLover\resources\views/header.blade.php ENDPATH**/ ?>