<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" style="height: 100%;">

<head id="header">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link rel="stylesheet" href="Style/home.css">

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Stylesheets -->
    <link rel="stylesheet" href="https://cdn.ciirus.com/WebTemplates/54951/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.ciirus.com/WebTemplates/54951/css/fotorama.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css"
        integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.ciirus.com/WebTemplates/54951/css/font-awesome-animation.min.css">
    <link rel="stylesheet" href="https://cdn.ciirus.com/WebTemplates/54951/css/magnific-popup.css">
    <link rel="stylesheet" href="https://cdn.ciirus.com/WebTemplates/54951/css/style22.css" type="text/css">
    <link rel="stylesheet" href="https://cdn.ciirus.com/WebTemplates/54951/css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="https://cdn.ciirus.com/WebTemplates/54951/css/owl.theme.default.min.css"
        type="text/css">

    <!-- Bootstrap and Jquery scripts -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    

    <title>For Rent Lover</title>
    <style>
    #navbarSupportedContent ul {
        float: right;
    }
  
    </style>
</head>

<body id="ciirusBody">

    <!-- navbar -->


    <!-- layout -->
    <div class="collapse navbar-collapse" style="background-color:#f1f1f1;">
        <hr>
        <nav class="navbar navbar-expand-lg navbar-light ">
            <a class="navbar-brand" href="#"><img src="images/5.jpg"
                    style="border-radius: 300px; width: 50px; height: 50px; margin-top: -15px"></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>


            <ul class="navbar-nav mr-auto">
                <li class="nav-item active" style="margin-right: 20px; ">
                    <a class="nav-link" href="#">Xem DS </a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Danh Muc
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="#">Action</a>
                        <a class="dropdown-item" href="#">Another action</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">Something else here</a>
                    </div>
                </li>
                <form class="form-inline my-2 my-lg-0" style="margin-left: 100px; margin-right: 20px;">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search this page"
                            style="width: 400px; border: 1px solid grey;  background: #f1f1f1;">
                        <div class="input-group-append">
                            <button class="btn btn-secondary" type="button">
                                <i class="fa fa-search"></i>
                            </button>
                        </div>
                    </div>
                </form>
                <li class="nav-item active">
                    <a class="nav-link" href="#">Contact Us</a>
                </li>
                <form class="login-signup-btn">
                    <div>
                        <button class="btn btn-danger">DANG NHAP</button></a></li>
                    </div>
                    <div>
                        <button class="btn btn-info">DANG KI</button></a></li>
                    </div>
                </form>
            </ul>
        </nav>
        <hr>
    </div>
    <hr>

    <!-- slide -->
    <div class="container-lg my-3">
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <!-- Carousel indicators -->
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
        </ol>
        <!-- Wrapper for carousel items -->
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="images/logo2.jpg" alt="First Slide" style="width: 100%; height: 300px">
            </div>
            <div class="carousel-item">
                <img src="images/logo2.jpg" alt="Second Slide">
            </div>
            <div class="carousel-item">
                <img src="images/logo.jpg" alt="Third Slide">
            </div>
        </div>
        <!-- Carousel controls -->
        <a class="carousel-control-prev" href="#myCarousel" data-slide="prev">
            <span class="carousel-control-prev-icon"></span>
        </a>
        <a class="carousel-control-next" href="#myCarousel" data-slide="next">
            <span class="carousel-control-next-icon"></span>
        </a>
    </div>
</div>
        <!--slider-->
        <!-- Content -->
        <div class="container">
            <h1 class="black front">For Rent Lover</h1>
            <div class="row mb-5">
                <div class="col-sm-9 front">
                    <div class="separator "></div>
                    <!--<h5 class="primary-color section-title ">Best &amp; More Popular Tours</h5>-->
                </div>
                <!--<div class="col-sm-3 front my-auto"><a role="button" class="btn btn-primary   mt-2 px-5 py-2" href="/search.aspx">more tours</a> </div>-->
            </div>
            <div class="row">
                <div class="col-md-3 col-sm-6">
                    <div class="product-grid3">
                        <div class="product-image3">
                            <a href="#">
                                <img class="pic-1" src="images/girl1.jpg">
                                <img class="pic-2" src="images/girl2.jpg">
                            </a>
                            <ul class="social">
                                <li><a href="#"><i class="fa fa-comments"></i></a></li>
                                <li><a href="#"><i class="fa fa-heart"></i></a></li>
                            </ul>
                            <span class="product-new-label">New</span>
                        </div>
                        <div class="product-content">
                            <h3 class="title"><a href="#">Men's Blazer</a></h3>
                            <div class="price">
                                $630.50 / Date
                                <!-- <span>$75.00</span> -->
                            </div>
                            <ul class="rating">
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star disable"></li>
                                <li class="fa fa-star disable"></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="product-grid3">
                        <div class="product-image3">
                            <a href="#">
                                <img class="pic-1" src="images/boy1.jpg">
                                <img class="pic-2" src="images/boy11.jpg">
                            </a>
                            <ul class="social">
                                <li><a href="#"><i class="fa fa-comments"></i></a></li>
                                <li><a href="#"><i class="fa fa-heart"></i></a></li>
                            </ul>
                        </div>
                        <div class="product-content">
                            <h3 class="title"><a href="#">Women's Designer Top</a></h3>
                            <div class="price">
                                $43.50 / Date
                            </div>
                            <ul class="rating">
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star"></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="product-grid3">
                        <div class="product-image3">
                            <a href="#">
                                <img class="pic-1" src="images/girl3.jpg">
                                <img class="pic-2" src="images/girl4.jpg">
                            </a>
                            <ul class="social">
                                <li><a href="#"><i class="fa fa-comments"></i></a></li>
                                <li><a href="#"><i class="fa fa-heart"></i></a></li>
                            </ul>
                            <span class="product-new-label">New</span>
                        </div>
                        <div class="product-content">
                            <h3 class="title"><a href="#">Men's Blazer</a></h3>
                            <div class="price">
                                $63.50 / Date
                                <span>$75.00</span>
                            </div>
                            <ul class="rating">
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star disable"></li>
                                <li class="fa fa-star disable"></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="product-grid3">
                        <div class="product-image3">
                            <a href="#">
                                <img class="pic-1" src="images/boy2.jpg">
                                <img class="pic-2" src="images/boy22.jpg">
                            </a>
                            <ul class="social">
                                <li><a href="#"><i class="fa fa-comments"></i></a></li>
                                <li><a href="#"><i class="fa fa-heart"></i></a></li>
                            </ul>
                            <span class="product-new-label">New</span>
                        </div>
                        <div class="product-content">
                            <h3 class="title"><a href="#">Men's Blazer</a></h3>
                            <div class="price">
                                $63.50
                                <span>$75.00</span>
                            </div>
                            <ul class="rating">
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star disable"></li>
                                <li class="fa fa-star disable"></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="product-grid3">
                        <div class="product-image3">
                            <a href="#">
                                <img class="pic-1" src="images/girl4.jpg">
                                <img class="pic-2" src="images/girl1.jpg">
                            </a>
                            <ul class="social">
                                <li><a href="#"><i class="fa fa-comments"></i></a></li>
                                <li><a href="#"><i class="fa fa-heart"></i></a></li>
                            </ul>
                            <span class="product-new-label">New</span>
                        </div>
                        <div class="product-content">
                            <h3 class="title"><a href="#">Men's Blazer</a></h3>
                            <div class="price">
                                $63.50
                                <span>$75.00</span>
                            </div>
                            <ul class="rating">
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star disable"></li>
                                <li class="fa fa-star disable"></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="product-grid3">
                        <div class="product-image3">
                            <a href="#">
                                <img class="pic-1" src="images/boy3.jpg">
                                <img class="pic-2" src="images/boy33.jpg">
                            </a>
                            <ul class="social">
                                <li><a href="#"><i class="fa fa-comments"></i></a></li>
                                <li><a href="#"><i class="fa fa-heart"></i></a></li>
                            </ul>
                            <span class="product-new-label">New</span>
                        </div>
                        <div class="product-content">
                            <h3 class="title"><a href="#">Men's Blazer</a></h3>
                            <div class="price">
                                $63.50
                                <span>$75.00</span>
                            </div>
                            <ul class="rating">
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star disable"></li>
                                <li class="fa fa-star disable"></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="product-grid3">
                        <div class="product-image3">
                            <a href="#">
                                <img class="pic-1" src="images/girl3.jpg">
                                <img class="pic-2" src="images/girl1.jpg">
                            </a>
                            <ul class="social">
                                <li><a href="#"><i class="fa fa-comments"></i></a></li>
                                <li><a href="#"><i class="fa fa-heart"></i></a></li>
                            </ul>
                            <span class="product-new-label">New</span>
                        </div>
                        <div class="product-content">
                            <h3 class="title"><a href="#">Men's Blazer</a></h3>
                            <div class="price">
                                $63.50
                                <span>$75.00</span>
                            </div>
                            <ul class="rating">
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star disable"></li>
                                <li class="fa fa-star disable"></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <h2 class="black-front">For Rent Lover</h2>

        <!-- footer -->
        <footer>
            <section id="footer">
                <div class="container">
                    <div class="row text-center text-xs-center text-sm-left text-md-left">
                        <!-- Contact Information -->
                        <div class="col-xs-12 col-md-6 col-lg-4">
                            <h6 class="white mt-4">Contact Us</h6>
                            <ul class="list-unstyled quick-links">
                                <li>
                                    <p class="white light">For Rent Lover offers around the clock customer support and
                                        partner with industry-leading property managers in a variety of locations. </p>
                                </li>
                                <li>
                                    <h5><i class="fas fa-map-marker-alt mr-2"></i>99 To Hien Thanh, Phuoc My, Son tra,
                                        Da
                                        Nang</h5>
                                </li>
                                <li>
                                    <h5><i class="fas fa-phone-square mr-2"></i>(+84) 395 587 260</h5>
                                </li>
                                <li>
                                    <h5><i class="fas fa-envelope mr-2"></i>info@forrentlover.com</h5>
                                </li>
                            </ul>
                        </div>
                        <!-- Social Networks -->
                        <div class="col-xs-12 col-md-6 col-lg-4">

                            <ul class="list-unstyled list-inline mt-3 social text-center">
                                <li><img class="avatar" src="image/4.jpg" width="300px"></li>
                                <li class="list-inline-item"><a href="#"><i class="fab fa-instagram"></i></a></li>
                            </ul>

                            <ul class="list-unstyled text-center quick-links mt-3">
                                <!--<li><a href="/content/destinations.aspx"><i class="fa fa-angle-double-right"></i>Destinations</a></li>-->
                                <li><a href="#"><i class="fa fa-angle-double-right"></i>About Us</a></li>
                                <li><a href="#"><i class="fa fa-angle-double-right"></i>Contact Us</a>
                                </li>
                                <li><a class="nav-link" href="/blog.aspx"><i
                                            class="fa fa-angle-double-right"></i>Blog</a>
                                </li>
                                <!--<li><a href="/index.aspx"><i class="fa fa-angle-double-right"></i>List With Us</a></li>-->
                            </ul>

                        </div>

                        <!-- Instagram Feed -->
                        <div id="instafeed" class="col-xs-12 col-md-6 col-lg-4 grid mx-auto text-center">
                            <h6 class="white mt-4 mb-3">Instagram Gallery</h6>
                            <div class="grid-sizer"></div>
                        </div>
                    </div>
                    <!-- GO UP rectangle -->
                    <!-- <div class="scale-up">
                    <a class="smooth-scroll  rectangle-right" href="#">
                        <div class="go-up px-1">
                            <i class="fas mb-2 fa-arrow-up"></i>
                            <br>
                            <h6 class="text-center letters-up">GO<br>UP</h6>
                        </div>
                    </a>
                </div> -->

                    <!-- Copyright Info-->
                    <div class="row">
                        <div class="col-12 mt-2 mt-sm-2 text-center text-white">
                            <div class="separatorfullwidth"></div>
                            <p class="white footer-bottom">© 2020 For Rent Lover</p>
                        </div>
                    </div>
                </div>

            </section>


        </footer>
</body>

</html><?php /**PATH C:\xampp\htdocs\laravel\ForRentLover\resources\views/demo.blade.php ENDPATH**/ ?>