<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('trang_chu')); ?>"><button class="btn btn-dark">Back Home</button></a>
<div class="container">
    <a href="<?php echo e(route('insert')); ?>">
        <button class="btn btn-info">
            <i class="fa fa-plus-circle"> ADD</i>
        </button>
    </a>
    <a href="<?php echo e(route('sort')); ?>">
        <button class="btn btn-success">
            <i class="fa fa-sort"> SORT</i>
        </button>
    </a>
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#staticBackdrop">
            <i class="fa fa-rank"> RANK</i>
        </button>
    <center>
        <table class="table">
            <thead class="thead-dark">
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th class="image">Image</th>
                    <th>Gender</th>
                    <th>Phone Number</th>
                    <th>Address</th>
                    <th>Description</th>
                    <th>Unit Price</th>
                    <th>Action</th>
                </tr>
            </thead>
            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tbody>
                <tr>
                    <td><?php echo $employee['id']; ?></td>
                    <td><?php echo $employee['name']; ?></td>
                    <td><img src="image/product/<?php echo e($employee->image); ?> " width="50px" height="50px"></td>
                    <td><?php echo $employee['id_type']; ?></td>
                    <td><?php echo $employee['phone_number']; ?></td>
                    <td><?php echo $employee['address']; ?></td>
                    <td><?php echo $employee['description']; ?></td>
                    <td><?php echo $employee['unit_price']; ?></td>
                    <td class="action">
                        <a href="<?php echo route('update', $employee['id']); ?>">
                            <button class="btn btn-warning" name="edit" value="<?php echo $employee['id']; ?>"><i
                                    class="fa fa-edit"></i></button>
                        </a>
                        <a href="<?php echo route('delete', $employee['id'] ); ?>">
                            <button class="btn btn-danger" name="delete" value="<?php echo $employee['id']; ?>"><i
                                    class="fa fa-trash"></i></button>
                        </a>
                    </td>
                </tr>
            </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </center>
    <div class="modal fade" id="staticBackdrop" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">XẾP HẠNG 3 NGƯỜI CÓ NHIỀU ĐƠN NHẤT</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Phần này chưa làm xong
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\Desktop\Diu Hoang\18_08_2020_ForRentLover\ForRentLover\resources\views/home_admin/manageEmployee.blade.php ENDPATH**/ ?>