<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('trang_chu')); ?>"><button class="btn btn-dark">Back Home</button></a>

<div class="container">
    <center>
        <table class="table">
            <thead class="table-info">
                <tr>
                    <th>Tên Khách Hàng</th>
                    <th>Tên Nhân viên</th>
                    <th>Ngày Đặt Lịch</th>
                </tr>
            </thead>
            <?php $__currentLoopData = $bill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bills): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tbody>
                <tr>
                    <td><?php echo $bills['customer_name']; ?></td>
                    <td><?php echo $bills['employee_name']; ?></td>
                    <td><?php echo $bills['date_book']; ?></td>
                </tr>
            </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </center>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\Desktop\Diu Hoang\18_08_2020_ForRentLover\ForRentLover\resources\views/home_admin/donhang.blade.php ENDPATH**/ ?>