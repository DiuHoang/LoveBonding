<?php $__env->startSection('content'); ?>


<div class="container">
<h1 class="page-title">Dịch vụ thuê người yêu</h1>

    <div class="row" style="margin-left: 15%;">
        <form action="" method="post">
            <?php echo csrf_field(); ?>
            <div class="region.region-content">
                <!-- Phan thong tin cua khach hang -->
                <fieldset class="panel panel-default form-wrapper">
                    <!-- <legend class="panel-heading">
                        <span class="panel-title fieldset-legend">Thong Tin Khach Hang</span>
                    </legend> -->
                    <div class="panel-body">
                        <!-- Username -->
                        <div class="form-item form-item-customer-name form-type-textfield form-group">
                            <label class="control-label">Ho Va Ten</label>
                            <span class="form-required" title="Trường dữ liệu này là bắt buộc.">*</span>
                            <input class="form-control form-text required" name="username" style="width: 700px;"/>
                            <div class="help-block">Vui lòng nhập tên của bạn.</div>
                        </div>
                        <!-- gender -->
                        <div class="form-item form-item-customer-gender form-type-radios form-group">
                            <label class="control-label">Gioi Tinh</label>
                            <span class="form-required" title="Trường dữ liệu này là bắt buộc.">*</span>
                            <div>
                                <!-- Default inline 1-->
                                <div class="custom-control custom-radio custom-control-inline">
                                    <input type="radio" class="custom-control-input" id="Male" name="gender"
                                        value="Male" checked="checked">
                                    <label class="custom-control-label" for="Male">Nam</label>
                                </div>

                                <!-- Default inline 2-->
                                <div class="custom-control custom-radio custom-control-inline">
                                    <input type="radio" class="custom-control-input" id="Female" name="gender"
                                        value="Female">
                                    <label class="custom-control-label" for="Female">Nu</label>
                                </div>

                                <!-- Default inline 3-->
                                <div class="custom-control custom-radio custom-control-inline">
                                    <input type="radio" class="custom-control-input" id="Mix" name="gender" value="Mix">
                                    <label class="custom-control-label" for="Female">Khac</label>
                                </div>
                            </div>
                        </div>
                        <!-- phone_number -->
                        <div class="form-item form-item-customer-name form-type-textfield form-group"
                            style="margin-top: 15px;">
                            <label class="control-label">Dien Thoai</label>
                            <span class="form-required" title="Trường dữ liệu này là bắt buộc.">*</span>
                            <input class="form-control form-text required" name="phone_number" />
                            <div class="help-block">Vui lòng nhập so dien thoai của bạn.</div>
                        </div>
                        <!-- image -->
                        <div class="form-item form-item-customer-name form-type-textfield form-group"
                            style="margin-top: 15px;">
                            <label class="control-label">Hinh Anh</label>
                            <span class="form-required" title="Trường dữ liệu này là bắt buộc.">*</span>
                            <input class="form-control form-text required" name="image" type="file" />
                            <div class="help-block">Vui lòng chon anh của bạn.</div>
                        </div>
                        <!-- email -->
                        <div class="form-item form-item-customer-name form-type-textfield form-group"
                            style="margin-top: 15px;">
                            <label class="control-label">Nhap Email</label>
                            <span class="form-required" title="Trường dữ liệu này là bắt buộc.">*</span>
                            <input class="form-control form-text required" name="email" type="email" />
                            <div class="help-block">Vui lòng nhập email của bạn.</div>
                        </div>
                        <!-- password -->
                        <div class="form-item form-item-customer-name form-type-textfield form-group"
                            style="margin-top: 15px;">
                            <label class="control-label">Password </label>
                            <span class="form-required" title="Trường dữ liệu này là bắt buộc.">*</span>
                            <input class="form-control form-text required" name="password" type="password"/>
                            <div class="help-block">Vui lòng nhập mat khau của bạn.</div>
                        </div>
                        <!-- re-password -->
                        <div class="form-item form-item-customer-name form-type-textfield form-group"
                            style="margin-top: 15px;">
                            <label class="control-label">Re-Password</label>
                            <span class="form-required" title="Trường dữ liệu này là bắt buộc.">*</span>
                            <input class="form-control form-text required" name="re_password" type="password"/>
                            <div class="help-block">Vui lòng nhập lai mat khau của bạn.</div>
                        </div>

                    </div>
                </fieldset>
                <?php if(count($errors) >0): ?>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="text-danger">
                        <h6><?php echo e($error); ?></h6>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php endif; ?>
            </div>

            <button id="button_register" class="btn btn-success">REGISTER</button>
        </form>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\ForRentLover\resources\views/home/signUp.blade.php ENDPATH**/ ?>