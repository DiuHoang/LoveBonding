<?php $__env->startSection('content'); ?>
<div class="container">
    <script>
		var msg = '<?php echo e(Session::get('alert')); ?>';
		var exist = '<?php echo e(Session::has('alert')); ?>';
		if(exist){
		  alert(msg);
		}
	</script>
	<form class="form_login" action="<?php echo e(route('dangnhap')); ?>" method="post">
    <?php echo csrf_field(); ?>
		<h2>FOR RENT LOVER</h2>

		<div class="name_pass">
			<label>Email</label>
			<input
				type="text"
				name="email"
				placeholder="Enter your email"
			>
			<label style="margin-top: 10px;">Password</label>
			<input
				type="password"
				name="password"
				placeholder="Password"
			>
		</div>
		<?php if(count($errors) >0): ?>
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li class="text-danger"> <p><?php echo e($error); ?></p></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
		<?php endif; ?>
		<button id="button_login" type="submit">SIGN IN</button>
		<label id="lbunder_login">Or sign in with</label>

		<div class="div_button">
			<button><i style="color: blue; padding-right: 1px;" class="fa fa-facebook"></i>Facebook</button>
			<button><i style="color: red; padding-right: 3px;"class="fa fa-google-plus"></i>Google</button>
		</div>

		<label id="lb_footer">Not a member?<a href="<?php echo e(route('dangki')); ?>"><span> Sign up now</span></a></label>
	</form>

</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\Desktop\Diu Hoang\18_08_2020_ForRentLover\ForRentLover\resources\views/dangnhap.blade.php ENDPATH**/ ?>