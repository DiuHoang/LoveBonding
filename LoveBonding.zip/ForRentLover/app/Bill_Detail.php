<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bill_Detail extends Model
{
    //
    protected $table = "bill_detail";
    protected $fillable = ['id_employee','id_bill',  'hours', 'price'];

    public function bill(){
        return $this->belongsTo('App\Bill', 'id_bill', 'id');
    }
    public function employee(){
        return $this->belongsTo('App\Employee', 'id_employee', 'id');
    }
}
