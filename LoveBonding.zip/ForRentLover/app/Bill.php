<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bill extends Model
{
    //
    protected $table = "bill";
    protected $fillable = ['id_cus', 'total', 'payment','note', 'date_book'];

    public function customer(){
        return $this->belongsTo('App\Customer', 'id_cus', 'id');
    }
    public function bill_detail(){
        return $this->hasMany('App\Bill_Detail', 'id_bill', 'id');
    }
}
