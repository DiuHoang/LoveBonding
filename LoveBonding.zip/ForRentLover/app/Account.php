<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Account extends Model
{
    //
    protected $table = "account";
    protected $fillable = ['id', 'name', 'gender', 'phone_number', 'image', 'email', 'password', 'repassword'];

    public function message(){
        return $this->hasMany('App\Message', 'id_account', 'id');
    }

}
