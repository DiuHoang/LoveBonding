<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Book extends Model
{
    //
    public $items = null;
    public $totalHours = 0;
    public $totalPrice = 0;

    public function __construct($oldList){
        if($oldList){
            $this->items = $oldList->items;
            $this->totalHours = $oldList->totalHours;
            $this->totalPrice = $oldList->totalPrice;
        }
    }

    public function add($item, $id, $hours = 0){
        if($item->unit_price == 0){
            $bookList = ['hours'=> 0, 'price'=>$item->unit_price, 'item'=>$item];
            if($this->items){
                if(array_key_exists($id, $this->items)){
                    $bookList = $this->items[$id];
                }
            }
            $bookList['hours'] = $bookList['hours'] + $hours;
            $bookList['price'] = $item->unit_price * $bookList['hours'];
            $this->items['id'] = $bookList;
            $this->totalHours = $this->totalHours + $hours;
            $this->totalPrice += $item->unit_price * $bookList['hours'];
        }
        else{
            $bookList = ['hours'=>0, 'price'=>$item->unit_price, 'item'=>$item];
            if($this->items){
                if(array_key_exists($id, $this->items)){
                    $bookList = $this->items[$id];
                }
            }
            $bookList['hours'] = $bookList['hours'] + $hours;
            $bookList['price'] = $item->unit_price * $bookList['hours'];
            $this->items[$id] = $bookList;
            $this->totalHours = $this->totalHours + $hours;
            $this->totalPrice += $item->unit_price * $bookList['hours'];
        }
    }

}
