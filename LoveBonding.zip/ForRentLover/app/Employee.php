<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    //
    protected $table = "employee";
    protected $fillable = ['name', 'id_type', 'age', 'address', 'phone_number', 'description', 'unit_price', 'image'];

    public function type_employee(){
        return $this->belongsTo('App\TypeEmployee','id_type','id');
    }
    public function bill_detail(){
        return $this->hasMany('App\Bill_Detail', 'id_employee', 'id');
    }

    public function message(){
        return $this->hasMany('App\Message', 'id_employee', 'id');
    }
}
