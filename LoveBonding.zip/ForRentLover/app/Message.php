<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Message extends Model
{
    //
    protected $table = "message";
    protected $fillable = ['id_account', 'id_employee', 'content'];

    public function account(){
        return $this->belongsTo('App\Account', 'id_account', 'id');
    }
    public function employee(){
        return $this->belongsTo('App\Employee', 'id_employee', 'id');
    }
}
