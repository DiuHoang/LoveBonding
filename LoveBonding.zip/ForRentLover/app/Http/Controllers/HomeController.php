<?php

namespace App\Http\Controllers;

use App\Account;
use Illuminate\Http\Request;
use App\Employee;
use App\Customer;
use App\Bill;
use App\Bill_Detail;
use App\Book;
use App\Contact;
use App\Message;
use App\TypeEmployee;
use Cron\HoursField;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Mockery\Matcher\Type;
use SebastianBergmann\Environment\Console;
use Session;


class HomeController extends Controller
{
    //

    //**********************--------------------------------------------USER-------------------------------------------------------*************************

    public function getIndexUser(){
       $employee = Employee::all();
       $type = TypeEmployee::all();

       return view('home_user.trangchu', compact('employee', 'type'));
       // return $type;
    }

    function AscPrice(Request $request){
        $employee = Employee::orderBy('unit_price', 'asc')->get();
        $type = TypeEmployee::all();

        return view('home_user.trangchu', compact('employee', 'type'));
    }

    function DescPrice(Request $request){
        $employee = Employee::orderBy('unit_price', 'desc')->get();
        $type = TypeEmployee::all();

        return view('home_user.trangchu', compact('employee', 'type'));
    }

    public function getLoaiNhanVien($gender){
        //lay san pham hien thi theo loai

        $emp_theoloai = Employee::where('id_type',$gender)->limit(3)->get();

        //lay san pham hien thi khac loai
        $emp_khac = Employee::where('id_type','<>',$gender)->limit(5)->get();

        //lay sn pham hien thi theo loai TypeProduct cho menu ben trai
        $type = TypeEmployee::all();

    	return view('home_user.loaiNhanVien',compact('emp_theoloai','emp_khac','type'));
    }

    public function getChitietNhanVien(Request $request){
        $nhanvien = Employee::where('id', $request->id)->first();
        $type = TypeEmployee::all();
        $message = new Message;

        return view('home_user.chitiet_NhanVien', compact('nhanvien', 'type', 'message'));
    }

    // public function getAddtoList(Request $request, $id){
    //     $employee = Employee::find($id);
    //     $oldList = Session('book')?Session::get('book'):null;
    //     $book = new Book($oldList);
    //     $book->add($employee, $id);
    //     $request->session()->put('book',$book);
    //     return view('home_user.datLich', compact('employee'));
    // }

    public function getBooked(Request $request, $id){
        $employee = Employee::find($id);
        $type = TypeEmployee::all();

        return view('home_user.datLich', compact('employee', 'type'));
    }

    public function postBooked(Request $request, $id){


        $customer = new Customer;
        $customer->name = $request->name;
        $customer->gender = $request->gender;
        $customer->address = $request->get('address');
        $customer->phone_number = $request->phone;
        $customer->note = $request->notes;
        $customer->save();

        $bill = new Bill;
        $bill->id_cus = $customer->id;
        $bill->total = $request->totalPrice;
        $bill->payment = $request->payment;
        $bill->note = $request->note;
        $bill->date_book = $request->check_in;

        $bill->save();


        $bill_detail = new Bill_Detail;
        $bill_detail->id_bill = $bill->id;
        $bill_detail->id_employee = $id;
        $bill_detail->hours = $request->hours;
        $bill_detail->price = $request->totalPrice;

        $bill_detail->save();


        return redirect()->back()->with('thb_datlich','Đặt lich thành công_Chờ ngày gặp mặt!');

    }

    public function getLienHe(Request $request){
        $type = TypeEmployee::all();

        return view('home_user.lienhe', compact('account', 'type'));
    }

    public function postLienHe(Request $request){
        $contact = new Contact;

        $contact->name = $request->name;
        $contact->phone_number = $request->phone_number;
        $contact->email = $request->email;
        $contact->content  =$request->content;

        $contact->save();
        return redirect()->back()->with('thb_contact','Chúng tôi đã nhận thông tin của bạn_Thường trả lời trong vài giờ!');
    }

    public function postReview(Request $request, $id){
        $nhanvien = Employee::where('id', $request->id)->first();
        $type = TypeEmployee::all();
        $message = new Message;
        $message->id_account = 1;
        $message->id_employee = $id;
        $message->content = $request->comment;

        $message->save();

        return view('home_user.chitiet_NhanVien', compact('nhanvien', 'type', 'message'));
    }

    //**********************--------------------------------------------LOGIN-------------------------------------------------------*************************
    /*Dang nhap*/

    public function getSignIn(){
        $type = TypeEmployee::all();
        return view('dangnhap', compact('type'));
    }

    public function postSignIn(Request $request){

        $this->validate($request,
            [
                'email'=>'required',
                'password'=>'required|min:6|max:20'
            ],
            [
                'email.required'=>'Please type in your name',
                'password.required'=>'Please type in your email',
                'password.min'=>'Password at least 6 characters',
                'password.max'=>'Password must not exceed 20 characters'
            ]
        );

        $email = $request->email;
        $password = $request->password;

        $account =Account::where('email',$email)->where('password',$password)->get();

        if(count( $account)>0){
            $request->session()->put('infor',$account);
            if($account[0]->level == 'admin'){
                // This is an account of admin
               return redirect('Index-Admin')->with('alert','[AD] Sign in successfully !');
            }
            else{
               // This is an account of customer
               return redirect('')->with('alert','[CUS] Sign in successfully !');
            }
        }

        else{
            return redirect('Sign-In')->with('alert','Your account is invalid !');
        }

    }

    /*Dang xuat*/
    public function getLogout(Request $request){
        $request->session()->forget('infor');
        return redirect('')->with('alert','Logout successfully');
    }

    /* Dang ki*/
    public function getSignUp(){
        $type = TypeEmployee::all();
        return view('home_user.dangki', compact('type'));
    }

    public function postSignUp(Request $request){

        $this->validate($request,
            [
                'email'=>'required|email|unique:account,email',
                'password'=>'required|min:6|max:20',
                'name'=>'required|unique:account,name',
                'repassword'=>'required|same:password'
            ],
            [
                'email.required'=>'Please type in your email',
                'email.email'=>'Email invalid',
                'email.unique'=>'Email exist',
                'password.required'=>'Please type in your password',
                'repassword.same'=>'Passwords are not the same',
                'password.min'=>'Password at least 6 characters'
            ]
        );

        $account = new Account;
        $account->name = $request->name;
        $account->gender = $request->gender;
        $account->phone_number = $request->phonenumber;
        $account->image = $request->image;
        $account->email = $request->email;
        $account->level = 'customer';
        $account->password = $request->password;
        $account->repassword = $request->repassword;
        $account->save();

        return redirect('Sign-In')->with('alert','Sign up successfully !');
    }

    /*Search function*/
     public function Search(Request $request){

        $search = $request->get('search');

        $employee = Employee::where('name','like','%'.$search.'%')->paginate(8);

        if(count($employee)>0){
            return view('home_user.trangchu', compact('employee'));
        }
        else{
            $employee = Employee::where('unit_price','>=',$search)->orderBy('unit_price', 'ASC');
            return view('home_user.trangchu', compact('employee'));
        }
    }


    //**********************--------------------------------------------ADMIN-------------------------------------------------------*************************
    public function getIndexAdmin(){
        $employees = Employee::all();
        $type = TypeEmployee::all();
        $customers = Customer::all();
        $bills = Bill::all();
        $totalPrice = DB::table('bill_detail')->sum('price');
        $mess = DB::table('message')
               ->join('customer', 'customer.id', '=', 'message.id_account')
               ->select('customer.name', 'message.content')
               ->get();
               //**
        $sum_bill = DB::table('bill')
                    ->select(DB::raw('sum(total) as s'),DB::raw('MONTH(date_book) month'))
                    ->groupby('month')
                    ->get();
        //var_dump($sum_bill);
        $gender = DB::table('employee')
                    ->select(DB::raw('count(id) as e'), 'id_type')
                    ->groupby('id_type')
                    ->get();
        $genders=   json_decode($gender, true);
        //var_dump($genders);
        $result = json_decode($mess, true);

        //var_dump($result);
        return view('home_admin.content', compact('employees', 'type', 'bills', 'totalPrice','mess', 'result', 'genders', 'customers'));
    }
///**********************************************************************************

    public function getBill(){
        $employees = Employee::all();
        $type = TypeEmployee::all();
        $customers = Customer::all();
        $bills = Bill::all();
        $totalPrice = DB::table('bill_detail')->sum('price');
        $mess = DB::table('message')
               ->join('customer', 'customer.id', '=', 'message.id_account')
               ->select('customer.name', 'message.content')
               ->get();
        $gender = DB::table('employee')
                    ->select(DB::raw('count(id) as e'), 'id_type')
                    ->groupby('id_type')
                    ->get();
        $genders=   json_decode($gender, true);
        //var_dump($genders);
        $result = json_decode($mess, true);
        //var_dump($result);
//cái này là cái chính
        $bill = json_decode(DB::table('bill')
               ->join('bill_detail', 'bill.id', '=', 'bill_detail.id_bill')
               ->join('employee', 'employee.id', '=', 'bill_detail.id_employee')
               ->join('customer', 'customer.id', '=', 'bill.id_cus')
               ->select('customer.name as customer_name' , 'employee.name as employee_name', 'bill.date_book')
               ->get(), true);
        $dt = Carbon::now('Asia/Ho_Chi_Minh');
        $date =  $dt->toDateString();
        return view('home_admin.donhang', compact('employees', 'type', 'bills', 'totalPrice','mess', 'result', 'genders', 'customers', 'bill', 'date'));
    }
///**********************************************************************************

    //lay du lieu tu bang employee
    public function getEmployee(){
        $employees = Employee::all();
        $type = TypeEmployee::all();
        $customers = Customer::all();
        $bills = Bill::all();
        $totalPrice = DB::table('bill_detail')->sum('price');
        $mess = DB::table('message')
               ->join('customer', 'customer.id', '=', 'message.id_account')
               ->select('customer.name', 'message.content')
               ->get();
               //**
        $months = DB::table('bill')
                ->select(DB::raw('MONTH(created_at) month'))
                ->get();
        //tao mang tao phan tu vong for
        $count_bill = DB::table('bill')
                    ->select(DB::raw('count(id) as c'),DB::raw('MONTH(date_book) month'))
                    ->groupby('month')
                    ->get();
        $result = json_decode($mess, true);
        // $bd = DB::table('bill_detail')
        //        ->join('employee', 'employee.id', '=', 'bill_detail.id_employee')
        //        ->select('employee.name', 'employee.image', DB::raw('count(bill_detail.id) as c'))
        //        ->groupby('id_employee')
        //        ->get();
        // var_dump($bd);
        return view('home_admin.manageEmployee', compact('employees', 'type', 'customers','bills', 'totalPrice','mess', 'result', 'months', 'count_bill'));
//  select employee.name, COUNT(bill_detail.id)
//  FROM employee, bill_detail
//  where employee.id = bill_detail.id_employee
//  GROUP BY(bill_detail.id_employee)
    }
//**************************DELETE*****************************************
    public function deleteEmployee($id){
        $bd = Bill_Detail::where('id_employee', $id)->get()->each->delete();
        //$bd->delete();
        $employee = Employee::find($id);
        $employee->delete();

        return redirect()->action("HomeController@getEmployee");

    }
//**************************SORT****************************************
    public function sortEmployee(){
        $employees = Employee::all();
        $type = TypeEmployee::all();
        $sophantu = count($employees);
        for ($i = 0; $i < $sophantu - 1; $i++)
        {
            for ($j = $i + 1; $j < $sophantu; $j++){
                if ($employees[$i]->unit_price > $employees[$j]->unit_price){
                    $temp = $employees[$i];
                    $employees[$i] = $employees[$j];
                    $employees[$j] = $temp;
                }
            }
        }
        $customers = Customer::all();
        $bills = Bill::all();
        $totalPrice = DB::table('bill_detail')->sum('price');
        $mess = DB::table('message')
               ->join('customer', 'customer.id', '=', 'message.id_account')
               ->select('customer.name', 'message.content')
               ->get();
               //**
        $months = DB::table('bill')
                ->select(DB::raw('MONTH(created_at) month'))
                ->get();
        //tao mang tao phan tu vong for
        $count_bill = DB::table('bill')
                    ->select(DB::raw('count(id) as c'),DB::raw('MONTH(created_at) month'))
                    ->groupby('month')
                    ->get();
        $result = json_decode($mess, true);
        return view('home_admin.manageEmployee', compact('employees', 'type','customers','bills', 'totalPrice','mess', 'result', 'months', 'count_bill'));
    }
//**************************ADD*****************************************
    public function viewAddEmployee(){
        return view('home_admin.insert');
    }
    public function AddEmployee(Request $rq){
        $new_employee = new Employee();
        $new_employee->name = $rq->name;
        $new_employee->id_type = $rq->gender;
        $new_employee->address = $rq->address;
        $new_employee->description = $rq->description;
        $new_employee->age = $rq->age;
        $new_employee->unit_price = $rq->price;
        $new_employee->phone_number = $rq->phone_number;
        $file_name = $rq->file('myFile')->getClientOriginalName();
        $new_employee->image = $file_name;
        $rq->file('myFile')->move('img',$file_name);
        $new_employee->save();

        return redirect()->action("HomeController@getEmployee");

    }
//**************************UPDATE*********************************
    public function viewUpdateEmployee($id){
        $employee = Employee::find($id);
        return view('home_admin.update', compact('employee'));
    }

    public function updateEmployee(Request $rq, $id){
        $employee = Employee::find($id);

        $employee->name = $rq->name;
        $employee->id_type = $rq->gender;
        $employee->address = $rq->address;
        $employee->phone_number = $rq->phone_number;
        $employee->age = $rq->age;
        if($rq->hasFile('newFile')){
            $file_name = $rq->file('newFile')->getClientOriginalName();
            $employee->image = $file_name;
            $rq->file('newFile')->move('img',$file_name);
        }
        $employee->description = $rq->description;
        $employee->unit_price = $rq->price;

        $employee->save();

        return redirect()->action("HomeController@getEmployee");

    }
    //****************************************************************
    public function orderByMonth()
    {
        $range = \Carbon\Carbon::now()->subMonth(12);
        $orderMonth = DB::table('bill')
                    ->select(DB::raw('month(date_book) as getMonth'), DB::raw('COUNT(*) as value'))
                    ->where('date_book', '>=', $range)
                    ->groupBy('getMonth')
                    ->orderBy('getMonth', 'ASC')
                    ->get();
        return view('home_admin.demo', compact('orderMonth'));
    }
    //******************************demo**********************************
    public function demo(Request $rq)
    {
        $mess = DB::table('messages')
               ->join('customer', 'customer.id', '=', 'message.id_cus')
               ->select('customer.name', 'message.content', 'message.status')
               ->get();
    }
    //***************************************
    public function getCustomer(){
        $customers = Customer::all();
        $type = TypeEmployee::all();
        $employees = Employee::all();
        $bills = Bill::all();
        $totalPrice = DB::table('bill_detail')->sum('price');
        $mess = DB::table('message')
               ->join('customer', 'customer.id', '=', 'message.id_account')
               ->select('customer.name', 'message.content')
               ->get();
               //**
        $months = DB::table('bill')
                ->select(DB::raw('MONTH(created_at) month'))
                ->get();
        //tao mang tao phan tu vong for
        $count_bill = DB::table('bill')
                    ->select(DB::raw('count(id) as c'),DB::raw('MONTH(created_at) month'))
                    ->groupby('month')
                    ->get();
        $result = json_decode($mess, true);
        return view('home_admin.viewCustomer', compact('customers', 'type', 'bills', 'totalPrice','mess', 'result', 'months', 'count_bill', 'employees'));
    }

/****************************************/
public function getSum(){
        $employees = Employee::all();
        $type = TypeEmployee::all();
        $customers = Customer::all();
        $bills = Bill::all();
        $totalPrice = DB::table('bill_detail')->sum('price');
        $mess = DB::table('message')
               ->join('customer', 'customer.id', '=', 'message.id_account')
               ->select('customer.name', 'message.content')
               ->get();
               //**
        $sum = DB::table('bill')
                    ->select(DB::raw('count(id) as c'), DB::raw('sum(total) as s'),DB::raw('MONTH(date_book) month'))
                    ->groupby('month')
                    ->get();
        //var_dump($sum_bill);
        $result = json_decode($mess, true);
        //var_dump($result);
        $sum_bill = json_decode($sum, true);
///**********************************************************************************
        return view('home_admin.tien', compact('employees', 'type', 'bills', 'totalPrice','mess', 'result', 'customers','sum_bill'));
    }

}
