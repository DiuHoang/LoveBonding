<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TypeEmployee extends Model
{
    //
    protected $table = "type_employee";
    protected $fillable = ['gender'];

    public function employee(){
    	return $this->hasMany('App\Employee','id_type','id');
    }
}
