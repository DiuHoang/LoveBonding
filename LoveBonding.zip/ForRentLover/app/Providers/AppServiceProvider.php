<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;
use App\Extensions\MongoSessionStore;
use App\TypeProduct;
use Session;
use App\Book;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        //
        view()->composer(['header','home.datLich'],function($view){
            if(Session('book')){
                $oldBook = Session::get('book');
                $book = new Book($oldBook);
                $view->with(['book'=>Session::get('book'), 'employee_book'=>$book->items, 'totalPrice'=>$book->totalPrice,'totalHours'=>$book->totalHours]);

            }
        });
    }
}
